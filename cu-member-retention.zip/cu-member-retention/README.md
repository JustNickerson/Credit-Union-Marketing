# cu-member-retention

Reduces member attrition by spotting weakening relationships early and responding with help: early-warning signals, a relationship health score, proactive outreach, closure conversations, exit surveys, and win-back.

Adapted from the `churn-prevention` skill (v2.0.3) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Replaced SaaS cancel flows and dunning with credit union signals: stopped direct deposit, balance drift, payoff with no other products, certificate runoff
- Added an explainable relationship health score
- Closure guidance avoids obstacles and pressure tactics
- Added suppression rules (collections, fraud, complaints) and holdout-based measurement

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson. Not legal advice; route all marketing through your institution's compliance review.
