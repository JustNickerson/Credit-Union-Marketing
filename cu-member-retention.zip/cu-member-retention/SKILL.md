---
name: cu-member-retention
description: "Reduce credit union member attrition: early-warning signals, relationship health scoring, proactive outreach, account-closure conversations, exit surveys and win-back."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (churn-prevention skill, v2.0.3, MIT)
---

# Credit Union Member Retention

You help credit unions keep members by noticing when relationships weaken and responding with help, not pressure. Member attrition rarely looks like a cancel button. It looks like a direct deposit that stops, balances that drift to another institution, a loan paid off with nothing left behind, or a certificate that matures and walks out the door.

## Before Starting

**Read the marketing context document** if available. Then understand:

1. **Current picture**: overall attrition rate, early attrition (first 90 to 180 days), and which products or segments lose members fastest
2. **Data available**: which signals can be pulled (direct deposit, balances, logins, card activity, loan payoff, certificate maturity) and how often
3. **Channels**: email, SMS, phone outreach, branch staff, in-app messages
4. **Constraints**: who can contact members proactively, suppression rules, compliance approvals

## Early-Warning Signals

| Signal | What it often means | Strength |
|---|---|---|
| Recurring direct deposit stops | Pay moved elsewhere or job change | Very strong |
| Balances trending down over 60 to 90 days | Money moving to another institution | Strong |
| Recurring transfers out to the same external institution | Building a relationship elsewhere | Strong |
| Autopay or bill pay removed | Unwinding the account | Strong |
| Digital banking logins stop | Disengagement | Medium |
| Debit card usage drops sharply | Different primary card | Medium |
| Loan paid off and no other active product | Relationship ending naturally | Medium |
| Certificate maturing, especially when rates elsewhere are higher | Rate-shopping runoff | Medium |
| Complaint or unresolved service issue | Service-driven risk | Medium to strong |
| Address change out of footprint | Possible move | Context |

Combine signals. One signal is a nudge; two or three together justify proactive outreach.

## Relationship Health Score

A simple, explainable score beats a black box. Example (0 to 100):

| Component | Points |
|---|---|
| Active direct deposit | 30 |
| Products held (5 per product, max 20) | 20 |
| Digital banking active in last 30 days | 15 |
| Debit or credit card used in last 30 days | 15 |
| Balance trend stable or up over 90 days | 10 |
| Tenure over 2 years | 10 |

Tiers: **Healthy** 70+, **Watch** 40 to 69, **At risk** under 40. Review the weights against actual closures after 6 months and adjust.

Don't use protected characteristics in the score, and document what it contains.

## Proactive Interventions

| Situation | Response | Channel |
|---|---|---|
| Direct deposit stopped | Service-style check-in: "Did your payroll change? Here's how to update it." | Email, then phone for high-value relationships |
| Balance drift plus external transfers | Value reminder relevant to their behavior (savings goal tools, a certificate option), not a hard pitch | Email or in-app |
| Loan paid off, no other products | Congratulations plus a next goal (savings, card, or a conversation) | Email |
| Certificate maturing | Clear options before the grace period ends, current APY with disclosures; required maturity notices go first | Email, phone for large balances |
| Digital logins stopped | Help with app access or new features | Email |
| Complaint or service issue | Resolve first; suppress marketing until resolved | Phone or branch |

Rules:
- Lead with help. A member who feels watched is less likely to stay.
- Don't mention specific transactions or external institutions by name in outreach ("We noticed you sent money to Bank X" reads as surveillance).
- Suppress marketing for members in collections, fraud cases, bankruptcy, or active complaints.

## Account-Closure Conversations

Members must be able to close accounts without obstacles. The goal of the closure moment is to understand, help where help is wanted, and leave the door open.

**Do:**
- Make the closure process clear on the website and in the app or branch
- Ask one or two short questions about why (see exit survey)
- Offer a relevant fix only when the reason is fixable (fee concern, service problem, digital issue), once, without pressure
- Confirm the closure in writing, including any final balance and what happens to scheduled payments
- Thank them, and tell them how to rejoin

**Don't:**
- Require a phone call or branch visit if other closures are handled digitally
- Hide the closure process or bury it behind multiple save offers
- Use guilt, fear, or false claims about consequences
- Keep accounts open against the member's request

## Exit Survey

Keep it to one required question plus optional comment:

**Why are you closing your account?**
- I'm moving out of the area
- Another institution offered better rates or rewards
- Fees
- Digital banking or app experience
- Service experience
- I consolidated accounts elsewhere
- Life change (marriage, divorce, estate)
- Other

Report results monthly by reason, segment, and tenure. Reasons that can be fixed (fees, digital, service) become product and operations priorities, not just marketing ones.

## Win-Back

- Former members who left for fixable reasons can hear from you after the problem is fixed ("We rebuilt our app"), if they have consented to contact
- Respect opt-outs and don't market to former members who asked not to be contacted
- Keep win-back to one or two touches per year

## Dormant Accounts

- Dormancy and unclaimed property (escheatment) rules require specific notices; those come from operations and are separate from marketing
- Marketing can support reactivation (see cu-lifecycle-emails reactivation journey) without replacing required notices

## Metrics

| Metric | Definition |
|---|---|
| Member attrition rate | Members who closed all accounts ÷ members at start of period |
| Early attrition | Closures within 90 and 180 days of joining |
| Relationship attrition | Members who keep a token account but lose direct deposit and activity |
| Product attrition | Loss of a specific product (direct deposit, card, certificate rollover) |
| Save rate | At-risk members contacted who are healthy 90 days later, vs. a holdout |
| Certificate rollover rate | Maturing balances retained |

Measure interventions against a holdout group; otherwise you can't tell what you saved from what would have stayed anyway (see cu-journey-measurement).

## Output Format

```
Retention plan: [segment or problem]
Signals used and data source:
Health score and tiers (if used):
Interventions by trigger (message, channel, timing, owner):
Suppression rules:
Closure-flow changes:
Measurement plan with holdout:
```

## Task-Specific Questions

1. Where are you losing members fastest: early, after a payoff, at certificate maturity, or gradually?
2. Which signals can you pull, and how often?
3. Who is allowed to make proactive outreach calls?
4. What does your current closure process look like for members?

## Related Skills

- **cu-lifecycle-emails**: onboarding (the best retention tool) and reactivation journeys
- **cu-journey-measurement**: holdouts and attrition reporting
- **cu-compliance-review**: pre-check retention offers and messages
- **cu-marketing-context**: segments, voice, and approved claims
