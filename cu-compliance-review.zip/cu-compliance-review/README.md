# cu-compliance-review

Pre-checks any credit union marketing piece before compliance review and returns findings by severity, questions for the reviewer, a revised draft, and a ready-to-paste disclosure block.

Adapted from the `copy-editing` skill (v2.1.1) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Replaced general copy-editing sweeps with ten credit union review sweeps: rates and terms, required statements, claims and proof, offers and bonuses, overall impression, targeting, channel rules, security, accessibility, voice
- Added the shared compliance guardrails and channel rules (email, SMS, web, social, paid ads, influencers, print, video)
- Checks drafts against the Approved Claims section of the marketing context document
- Output is built for a compliance handoff: severity, quoted text, rule, and fix

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson. Not legal advice; route all marketing through your institution's compliance review.
