# Channel Rules

Channel-specific checks that sit on top of guardrails.md. Platform policies change often; confirm current rules in each platform's ad policy center before launch.

## Contents
- Email
- SMS and text
- Websites and landing pages
- Organic social
- Paid social and search
- Influencers, creators, and employee advocacy
- Print, out-of-home, and branch signage
- Video and audio

---

## Email
- Commercial email: accurate From name, subject matching content, working unsubscribe honored within 10 business days, physical postal address (CAN-SPAM)
- Keep marketing separate from required notices and service messages
- No sensitive data, no credential requests, links to the institution's own domain
- Rate in the subject line means the body carries the full required disclosures

## SMS and text
- Marketing texts need prior express written consent; keep consent records (timestamp, source, exact disclosure shown)
- Identify the credit union in every message; include opt-out instructions ("Reply STOP to opt out") in at least the first message and periodically
- Honor opt-outs promptly through any reasonable method the member uses, within the window current FCC rules require
- Quiet hours: no marketing before 8 a.m. or after 9 p.m. in the recipient's time zone, and stricter where state law requires
- Keep marketing separate from fraud alerts, one-time passcodes, and account alerts (different consent rules apply)
- Never include links that look like phishing; use the institution's own domain or registered branded short domain
- See the cu-sms skill for full guidance

## Websites and landing pages
- Required disclosures on the same page as the claim, close to it, not only behind a link
- Rate pages show "as of" dates and APY or APR
- Insurance statement and Equal Housing logo where required
- Third-party or partner pages: a speed-bump or clear notice when members leave the institution's site, if your policy requires it
- Accessibility: alt text, contrast, keyboard navigation, readable disclosures (not images of text)

## Organic social
- A post that states a rate, term, payment, or bonus is an advertisement; it needs the required disclosures in the post or a clearly linked landing page, per your institution's policy
- Character limits don't remove disclosure requirements; use general terms ("great rates on auto loans") or put the full terms one click away with clear labeling, as compliance approves
- Moderate comments: don't confirm member account details publicly; move service issues to private channels
- Respond to complaints consistently; some may need to be logged under your complaint policy

## Paid social and search
- **Meta (Facebook, Instagram):** ads for credit and other financial products must run under the financial products and services special ad category, which limits targeting by age, gender, and ZIP code and restricts lookalike audiences
- **Google Ads:** in the U.S., consumer credit ads are covered by personalized advertising restrictions that prohibit targeting by sensitive characteristics such as age, gender, parental status, marital status, or ZIP code
- **LinkedIn, TikTok, and others:** check each platform's financial services policy before launch
- Ad copy with trigger terms needs the disclosures in the ad where space allows, and on the landing page in all cases
- Keep a record of targeting criteria for credit campaigns

## Influencers, creators, and employee advocacy
- Paid or gifted endorsements need a clear and conspicuous disclosure (for example "#ad" or "Paid partnership with [CU]") at the start of the post, not buried in hashtags (FTC Endorsement Guides)
- Creators can't state rates, terms, or claims the institution hasn't approved
- Provide approved talking points and required disclosures in writing
- Employees posting about products should follow the institution's social media policy and disclose their employment

## Print, out-of-home, and branch signage
- Disclosures legible at the expected viewing distance
- Rate-valid dates on anything that stays up for weeks
- Retire expired promotions on a schedule

## Video and audio
- On-screen disclosures must stay up long enough to read and be large enough to see on a phone
- Audio ads that mention rates or terms need the required disclosures spoken or a clear source for full terms, per compliance
- Insurance statement requirements have specific exemptions for short broadcast ads; confirm with compliance
