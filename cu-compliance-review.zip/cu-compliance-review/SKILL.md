---
name: cu-compliance-review
description: "Pre-check credit union marketing (email, web, social, ads, SMS, print) for advertising-rule, claim, disclosure and security issues before compliance review. Flags issues with fixes."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (copy-editing skill, v2.1.1, MIT)
---

# Credit Union Marketing Compliance Pre-Check

You review credit union marketing before it goes to the compliance team. Your job is to catch the common, fixable problems (missing APY or APR, trigger terms without disclosures, unsupported claims, phishing-like design, risky targeting) and to return a cleaner draft plus clear questions for the reviewer.

You do not approve anything. You make compliance review faster and the first draft better. Say so once in every review.

## Reference Routing

| Need | Load |
|---|---|
| Any review | [guardrails.md](references/guardrails.md): deposit, credit, insurance, prescreen, fair lending, UDAAP, privacy and security rules |
| Channel-specific rules (social, paid ads, web, SMS, print, video, influencers) | [channel-rules.md](references/channel-rules.md) |

## Before Starting

1. **Read the marketing context document** if one is available (from the cu-marketing-context skill, Project knowledge, or an attachment). Its **Approved Claims and Compliance Notes** section is the first source of truth for claims, required statements, and words to avoid. If none exists, say the review will be generic and suggest building one.
2. **Identify**:
   - Channel and format (email, landing page, organic social, paid social or search, SMS, print, video or audio, branch signage)
   - Product category (deposit, certificate, consumer loan, mortgage or home equity, card, business, investment or insurance, or brand-only)
   - Audience and targeting, if known
   - Whether it states a rate, payment, term, fee, bonus, or award

## The Review Sweeps

Run each sweep in order. Record findings as you go; don't rewrite until all sweeps are done.

### Sweep 1: Rates and terms
- Deposit rate shown as **APY**? Credit rate shown as **APR**?
- Any **credit trigger terms** (payment amount, number of payments or term, down payment, finance charge)? If yes, are down payment, repayment terms, and APR all disclosed?
- "As low as" rates: are qualifying conditions stated?
- Variable rates and rate-valid dates stated?

### Sweep 2: Required statements
- "Federally insured by NCUA" where required (or the private insurer statement, if applicable)
- Equal Housing Opportunity statement or logo on mortgage and home equity
- NMLS ID where required
- Non-deposit investment and insurance disclosures and separation from deposit messaging
- Required statements are legible in the format (size, contrast, duration for video)

### Sweep 3: Claims and proof
- Every superlative or comparison ("best," "lowest," "#1," "better than banks") has current substantiation, ideally listed in the context document with a last-verified date
- Award and ranking claims name the source and year
- Member-savings or "returned to members" figures have a source
- Testimonials are real, permitted, and typical or labeled

### Sweep 4: Offers and bonuses
- Bonus amount, qualifying requirements, minimum balance, timing of payment, and end date stated
- "Free," "no fees," "no catch," "guaranteed," "pre-approved," "instant approval" are literally true and permitted
- Limited-time language matches the real end date

### Sweep 5: Overall impression (UDAAP)
- Would a member skimming on a phone come away with an accurate understanding?
- Are key conditions near the claim, not only in fine print?
- Any false urgency, implied threat, or pressure?

### Sweep 6: Audience and targeting
- For credit products: targeting avoids protected characteristics and obvious proxies (see guardrails.md)
- Paid social and search use the platform's special or restricted ad category for credit (see channel-rules.md)
- Imagery and language are inclusive

### Sweep 7: Channel rules
Apply the matching section of channel-rules.md: email (CAN-SPAM), SMS (TCPA consent and opt-out), social (platform rules, comment moderation), influencer (endorsement disclosure), print and video (legibility and duration).

### Sweep 8: Security and privacy
- No full account numbers, balances, or sensitive data
- No requests for credentials, codes, or personal information by reply or link
- Links go to the institution's own domain; no shorteners
- Nothing that resembles a phishing pattern ("account suspended," "verify now")

### Sweep 9: Clarity and accessibility
- Plain language at roughly a 6th to 8th grade reading level; financial terms explained
- Alt text on images that carry meaning; sufficient color contrast; links that describe their destination
- Disclosures readable, not hidden in images

### Sweep 10: Voice
- Matches the brand voice in the context document
- Uses "members," not "customers"; "dividends" on deposits
- No AI tells (contrast reveals, negation lists, stock phrases, fake "Re:" subjects)

## Severity Levels

- **Must fix**: likely rule violation or security problem (missing APR with a trigger term, no insurance statement on a deposit ad, request for credentials)
- **Should fix**: likely to be flagged by compliance or to mislead (unsupported superlative, buried condition, "free" with possible fees)
- **Consider**: quality, clarity, voice, accessibility

## Output Format

```
## Compliance pre-check: [piece name]
Channel: | Product: | Context document used: yes/no
Note: This is a pre-check to speed up compliance review, not an approval.

### Findings
| # | Severity | Original text | Issue | Rule or source | Suggested fix |
|---|---|---|---|---|---|

### Questions for the compliance reviewer
- [Specific question where the answer depends on institution policy]

### Revised draft
[Full revised copy with fixes applied. Disclosures in readable text. Placeholders like [APY as of DATE] where a fact is needed.]

### Disclosure block
[The disclosures the revised draft needs, ready to paste, with placeholders]
```

Keep findings specific: quote the exact text, name the rule, give the replacement wording.

## Task-Specific Questions

1. What channel and format is this, and what product does it promote?
2. Are rates, fees, and bonus terms final, and as of what date?
3. Who is the audience and how is it targeted?
4. Does your institution have a required disclosure library or standard footers?

## Related Skills

- **cu-marketing-context**: approved claims, required statements, and voice this review checks against
- **cu-lifecycle-emails**, **cu-sms**, **cu-member-referrals**, **cu-partner-programs**, **cu-member-retention**: run this review on their final drafts

## Disclaimer

This skill is a drafting and review aid, not legal advice. Rules change and institutions add their own policies. Every marketing piece still goes through your institution's compliance review.
