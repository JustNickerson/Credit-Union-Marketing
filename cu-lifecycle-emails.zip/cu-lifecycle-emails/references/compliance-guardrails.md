# Compliance Guardrails for Credit Union Email

A drafting aid for U.S. credit unions, not legal advice. Rules change and institutions add their own policies, so every email that advertises an account or credit product goes to compliance review. Use this file to catch the common problems before that review.

## Contents
- Deposit advertising (Truth in Savings)
- Credit advertising (Truth in Lending)
- Share insurance statement
- Prescreened and "pre-approved" offers
- Fair lending and targeting
- Unfair, deceptive or abusive practices (UDAAP)
- Email law (CAN-SPAM) and consent
- Privacy and security
- Mortgage and home equity
- Pre-send checklist

---

## Deposit advertising (Truth in Savings)

Credit unions follow NCUA's Truth in Savings rule (12 CFR Part 707) for share and certificate accounts.

- **State earnings as APY.** If you advertise a rate of return, use "Annual Percentage Yield (APY)." A dividend rate may appear alongside it but never more prominently.
- **Advertising an APY triggers more disclosures**, such as: whether the rate is variable, the period the rate is offered or that it is accurate as of a date, any minimum balance to obtain the APY, the minimum opening deposit if it exceeds a threshold, that fees could reduce earnings, and for certificates the term and early withdrawal penalty.
- **Bonuses** (for example "$200 when you open checking and set up direct deposit") need the amount, the qualifying requirements, the minimum balance, and when the bonus is paid.
- **"Free" and "no cost"** cannot be used if a maintenance or activity fee could apply, or if a minimum balance is required to avoid one.
- **Avoid "profit"** to describe earnings, and never describe an account in a misleading way.

## Credit advertising (Truth in Lending)

Regulation Z governs loan and credit card ads.

- **Any rate must be stated as an APR** (Annual Percentage Rate). If the rate can increase after consummation, say so.
- **Trigger terms.** If an email states any of these, it must also disclose the down payment, the repayment terms, and the APR:
  - the amount or percentage of a down payment
  - the number of payments or period of repayment ("60-month term")
  - the amount of any payment ("payments as low as $289/month")
  - the amount of any finance charge
- **General statements are safe** without those disclosures: "low rates," "flexible terms," "easy monthly payments."
- **"As low as" rates** need the conditions that qualify for that rate, such as credit history, term, autopay, or vehicle age.
- **Rate discounts** (for example 0.25% off with autopay) need the conditions stated clearly.

## Share insurance statement

- Federally insured credit unions must include the official advertising statement, "Federally insured by NCUA," in advertisements (12 CFR Part 740), with limited exemptions such as ads that do not relate to member accounts. Ask compliance which emails your institution treats as exempt.
- Never describe loans, investments, or insurance products as federally insured.
- Non-deposit investment products need the "not insured, no guarantee, may lose value" style disclosures and separation from deposit messaging.

## Prescreened and "pre-approved" offers

- "Pre-approved," "pre-qualified" and similar words imply a firm offer of credit. Use them only when the offer is a genuine prescreened firm offer under the Fair Credit Reporting Act, which also requires the prescreen opt-out notice.
- For ordinary cross-sell, use "You may qualify" or "See your rate" language and route the member to an application.
- Never say "guaranteed approval."

## Fair lending and targeting

The Equal Credit Opportunity Act and Fair Housing Act prohibit discrimination in credit.

- Do not segment, target, or exclude members for credit offers based on race, color, religion, national origin, sex, marital status, age (with narrow exceptions), receipt of public assistance, or other protected characteristics, or on obvious proxies for them (such as targeting by neighborhood in a way that tracks race).
- Be cautious with lookalike or AI-built audiences for credit products; document the criteria used.
- Imagery and language should be inclusive and should not suggest a product is only for certain groups.

## UDAAP

Unfair, deceptive, or abusive acts or practices apply to all marketing.

- The overall impression must be accurate, not just each sentence.
- Important conditions belong near the claim, not only in fine print.
- Do not create false urgency about an account ("Your account will be closed") in marketing.
- Do not imply a member must buy a product to keep an account or a rate unless that is true and disclosed.

## Email law (CAN-SPAM) and consent

For commercial (marketing) email:
- Accurate "From" name and a subject line that matches the content
- A working unsubscribe link, honored within 10 business days
- The institution's valid physical postal address
- Identified as an advertisement where required

Transactional and relationship messages (statements, alerts, account changes) have different rules. Keep marketing out of required notices, and keep a marketing opt-out from suppressing service messages.

## Privacy and security

Phishing that imitates financial institutions is common. Email design is a security control.

- **Never include** full account numbers, card numbers, balances, Social Security numbers, or other sensitive personal information in marketing email. Last four digits only, and only when needed.
- **Never ask** members to reply with personal information or to "verify" credentials through a link.
- **Link to your own domain**, with descriptive link text; avoid link shorteners and third-party redirect domains in member email.
- **Repeat the safety line** in onboarding: "We will never ask for your password, PIN, or a one-time code by email, text, or phone."
- Follow your institution's GLBA privacy notice and data-sharing choices, including for partner co-marketing.

## Mortgage and home equity

- Use the Equal Housing Opportunity (or Equal Housing Lender) statement or logo in mortgage and home equity advertising, plus the institution's NMLS ID where your state or policy requires it.
- Home equity line ads have additional Regulation Z requirements (for example, introductory rates must show how long they last and the rate after). Always route to compliance.

---

## Pre-send checklist

Answer each before handing the email to compliance:

1. Does the email state any rate? APY for deposits, APR for credit, plus required disclosures.
2. Does it use a trigger term (payment amount, term length, down payment, finance charge)? Then include down payment, repayment terms, and APR.
3. Does it advertise a share or certificate account? Include "Federally insured by NCUA" unless compliance confirms an exemption.
4. Does it say "free," "pre-approved," "guaranteed," or "no fees"? Confirm each is literally true and permitted.
5. Is any bonus fully described (amount, requirements, timing)?
6. Is the audience selection free of protected characteristics and their proxies for credit offers?
7. Is any sensitive information in the email? Remove it.
8. Do all links go to the institution's own domain?
9. Is there a working unsubscribe link and a physical address?
10. Is the overall impression accurate to a member skimming it on a phone?
