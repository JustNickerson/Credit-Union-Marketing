# Email Copy Guidelines for Credit Unions

## Contents
- Structure and formatting
- Tone and reading level
- AI tells to avoid
- Length and calls to action
- Personalization
- Segmentation
- Testing and metrics

## Structure and formatting

1. **Hook**: the reason you're writing, in the first line
2. **Context**: why it matters to this member now
3. **Value**: the useful part (steps, a tip, a benefit with its conditions)
4. **CTA**: one primary action
5. **Sign-off**: a real team or person, with how to reach a human

Short paragraphs (1 to 3 sentences), white space, mobile-first. Put disclosures in readable text near the claim they qualify, and full terms at the bottom.

## Tone and reading level

- Warm, plain, specific. Write like a knowledgeable person at a local branch.
- Aim for a 6th to 8th grade reading level. Financial terms get a short plain-English explanation the first time.
- Use "you" and "we." Active voice.
- Celebrate member milestones without being cute about money stress.
- Never shame members about balances, credit, or fees.

## AI tells to avoid

Members recognize generated email and stop trusting it. Write from the specific thing you want them to know or do.

- **Contrast reveals**: "It's not just a checking account, it's a partner." State the point directly.
- **Negation lists**: "No fees, no hassle, no catch." Also a compliance risk if any fee exists.
- **Self-answered questions and colon reveals**: "The best part? It's free."
- **Stock phrases**: "Unlock," "Elevate," "Say goodbye to," "Take control of your financial future," "Here's the thing."
- **Stock openers and closers**: "I hope this email finds you well," "Just checking in," "Feel free to reach out with any questions."
- **Bait subjects**: fake "Re:" or "Fwd:", "Urgent," "Action required." These also resemble phishing.
- **Em dashes** in subject lines and preview text; at most one or two in an email body.

## Length and calls to action

- Service-style and milestone nudges: 50 to 125 words
- Educational: 150 to 300 words
- Story or member-impact: up to 400 words

CTA buttons say action plus outcome: "Set up direct deposit," "Turn on alerts," "See your rate." Avoid "Click here" and "Learn more" as the only primary CTA.

## Personalization

- **First name** with a fallback ("Hi there")
- **Join channel** (branch, digital, dealer, partner) to explain context
- **Milestones completed** so you never ask for something already done
- **Partner or employer name** for SEG journeys
- Never personalize with balances, account numbers, or inferred sensitive information

## Segmentation

**By relationship stage**: new (0 to 90 days), established, at risk (stopped deposits, declining activity), inactive

**By behavior**: digital enrolled or not, direct deposit or not, product count, card usage

**By channel and consent**: email, SMS, and in-app consent are separate; respect each

Do not segment credit offers by protected characteristics or obvious proxies (see compliance-guardrails.md).

## Testing and metrics

**Test**: subject lines, send time, CTA wording, journey timing, and the order of onboarding milestones. Change one variable at a time.

**Measure**:
- Journey goal conversion (the behavior, not the click)
- Milestone completion by day 30 and day 90
- Products per member and early attrition
- Click rate and unsubscribe rate (keep unsubscribes low; a spike signals frequency or relevance problems)
- Lift against a holdout group, where volume allows

Open rates are inflated by mail privacy features; use them for directional subject-line tests only.
