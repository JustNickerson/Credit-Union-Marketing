# Member Journey Templates

Journey templates for credit unions. Adjust timing to your data and approvals process. Every journey needs an exit condition so members who complete the goal stop receiving nudges.

## Contents
- New member onboarding (first 90 days)
- Digital banking enrollment nudge
- Direct deposit
- New loan onboarding
- Loan payoff
- Certificate maturity
- Card activation and first use
- Partner and employer (SEG) program
- Life events
- Reactivation of inactive members
- Lifecycle audit checklist

---

## New member onboarding (first 90 days)

**Trigger**: membership account opened
**Goal**: primary financial institution behaviors, usually digital banking, direct deposit, e-statements, and a debit card in use
**Exit**: each milestone email suppresses itself once that milestone is complete

**Email 1: Welcome (immediate)**
- Subject: Welcome to [Credit Union]. Here's what to do first
- Thank them for joining and explain, in a sentence, what membership means (member-owned, not-for-profit)
- One action: set up online and mobile banking
- Security line: what you will never ask for
- Who to contact and how

**Email 2: Mobile app and digital banking (day 2 to 3, if not enrolled)**
- Subject: Your account, in your pocket
- Two or three things the app makes easy (mobile deposit, transfers, alerts)
- One action: download and sign in

**Email 3: Direct deposit (day 5 to 7, if no direct deposit)**
- Subject: Get paid here in about 5 minutes
- Show how to switch (pre-filled direct deposit form, or a switch tool if offered)
- Benefit framed plainly, such as early pay if offered, with conditions stated
- If a bonus applies, include full bonus terms (see compliance-guardrails.md)

**Email 4: Debit card and alerts (day 10 to 14)**
- Subject: Three settings worth turning on
- Card controls, transaction alerts, travel notices
- Reinforces security and trust

**Email 5: E-statements and paperless (day 14 to 21, if paper)**
- Subject: Skip the paper statements
- One action: switch to e-statements

**Email 6: Meet the credit union (day 21 to 30)**
- Subject: What being a member means
- Member-ownership story, local impact, financial wellness resources
- Soft link to education content; no product pitch

**Email 7: First relevance-based offer (day 30 to 45)**
- Choose based on data the member has shared, such as an auto loan refinance check for members with an external auto payment, or a savings goal tool
- Subject: Could you be paying less on your car?
- General language unless you include full Truth in Lending disclosures

**Email 8: 60-day check-in (day 60)**
- Subject: How's everything going?
- Ask for quick feedback (one-question survey)
- Offer help from a real person

**Email 9: Second product (day 75 to 90)**
- Based on behavior and stated needs: savings, credit card, certificate, or a loan conversation
- Subject: A next step that fits [goal]

**Key metrics**: milestone completion rates, products per member at 90 days, early account closures.

---

## Digital banking enrollment nudge

**Trigger**: member has not enrolled 3 days after account opening (or any member found not enrolled)
**Format**: 2 to 3 emails, 3 to 5 days apart
- Remind what they get, show the steps with screenshots, offer phone or branch help
- **Exit**: enrollment completed

## Direct deposit

**Trigger**: no recurring direct deposit 7 days after opening, or direct deposit stops (a strong attrition signal)
**Format**: 2 emails for new members; 1 service-style check-in when deposits stop
- For stopped deposits, lead with help ("Did your employer or payroll change?"), not a sales message
- **Exit**: direct deposit detected

## New loan onboarding

**Trigger**: loan funded
**Goal**: on-time payments, autopay, and a positive first experience
- Email 1 (immediate): Welcome to your loan; how to view it in the app; set up autopay
- Email 2 (before first payment): payment reminder and options
- Email 3 (day 30 to 45): related value, such as GAP or protection products for auto loans, only if offered and with required disclosures, or savings tools
- **Exit**: autopay set up removes the autopay prompts

Indirect auto loan members (who joined through a dealership) often have no other relationship. Treat this journey as their membership welcome too.

## Loan payoff

**Trigger**: loan paid in full
- Email 1: Congratulations, with the title or lien-release process explained
- Email 2 (2 to 4 weeks later): what's next: redirect the old payment amount into savings, or a next-goal conversation
- Keep the tone celebratory; avoid an immediate new-loan pitch

## Certificate maturity

**Trigger**: certificate approaching maturity
- Required maturity notices are separate and come first. Marketing supplements them; it never replaces them.
- Marketing email (inside the notice window): options at maturity, current rates stated as APY with required disclosures, and how to act before the grace period ends

## Card activation and first use

**Trigger**: card issued and not activated after 7 days; or activated and unused after 30 days
- Activation reminder with the steps
- First-use nudge: digital wallet setup, card controls

## Partner and employer (SEG) program

Select employee groups (SEGs) and partner organizations are a major membership channel.

**Trigger**: lead from a partner channel (employer benefits page, event, partner referral)
**Goal**: account opened, then onboarding
- Email 1: Welcome from [Partner] and [Credit Union]; why the partnership exists; member eligibility explained
- Email 2: The one or two benefits most relevant to that group (for example payroll direct deposit, first-time homebuyer education)
- Email 3: Open an account; what to bring; how long it takes
- After opening: hand off to new member onboarding, with partner context carried into personalization
- Confirm partner data sharing follows your privacy notice and the partner agreement

## Life events

Use only data members have shared or that is clearly appropriate (for example, a member who started a mortgage pre-qualification). Avoid inferring sensitive life events from transaction data.

- **First home**: education series, homebuyer workshop invite, pre-qualification (with mortgage disclosures)
- **New driver or teen account**: youth and teen account tools, financial education
- **Graduation**: student loan refinance education, first credit card education
- **Retirement planning**: certificates, investment services (with non-deposit product disclosures)

## Reactivation of inactive members

**Trigger**: no member-initiated activity for 6 to 12 months (set with operations; note that dormancy and escheatment rules are separate requirements with their own notices)
**Format**: 2 to 4 emails over 4 to 6 weeks
- Email 1: Check-in; is the contact info right; how to sign in
- Email 2: What's new (app features, branches, rates in general terms)
- Email 3: A reason to come back that fits their history
- Email 4: Clear choice: keep the account active, update preferences, or close it with help
- **Exit**: member-initiated activity

---

## Lifecycle audit checklist

Use this to find gaps in an existing program. For each, note: exists, trigger used, exit condition, last reviewed.

**Onboarding**
- [ ] Welcome email within minutes of account opening
- [ ] Digital banking enrollment nudge with exit condition
- [ ] Direct deposit journey
- [ ] Debit card activation and first-use
- [ ] E-statement conversion
- [ ] Onboarding for indirect (dealer) loan members

**Product**
- [ ] New loan onboarding and autopay
- [ ] Loan payoff and next goal
- [ ] Certificate maturity marketing (supplementing required notices)
- [ ] New credit card onboarding

**Relationship**
- [ ] Second-product journey based on behavior or stated needs
- [ ] Life-event journeys with appropriate data use
- [ ] Partner and employer (SEG) program journeys
- [ ] Feedback or NPS check-in

**Retention**
- [ ] Stopped direct deposit alert (service-style)
- [ ] Reactivation for inactive members
- [ ] Account closure survey

**Governance**
- [ ] Every marketing email reviewed by compliance in its current version
- [ ] Suppression for members in collections, fraud cases, or active complaints
- [ ] Frequency cap across journeys
- [ ] Holdout groups to measure lift
