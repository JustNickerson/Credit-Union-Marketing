# Credit Union Lifecycle Emails: an AI agent skill

An AI agent skill that designs, writes, and audits lifecycle email journeys for credit unions, with financial-marketing compliance guardrails built in.

It works with Claude (app and Claude Code) and any agent that supports the [Agent Skills](https://agentskills.io) format.

## Why I built it

General-purpose AI marketing skills are written for SaaS companies: trials, signups, upgrades, churn. Credit unions run on a different model. Members are owners, success is measured in relationship depth rather than conversions, and every email that mentions a rate or a loan is regulated.

I adapted the `emails` skill from Corey Haines' open-source [marketingskills](https://github.com/coreyhaines31/marketingskills) library for that reality, so an AI agent produces drafts a credit union marketer can actually send to compliance review.

## What changed from the original

| Area | Original (SaaS) | This version (credit union) |
|---|---|---|
| Audience | users, subscribers | members (owners) |
| Success metric | activation, upgrade, revenue | primary financial institution behaviors, products per member, early attrition |
| Journeys | welcome, nurture, trial conversion, re-engagement | 90-day new member onboarding, direct deposit, digital banking, new loan, loan payoff, certificate maturity, partner/employer (SEG) programs, life events, reactivation |
| Compliance | none | Truth in Savings (APY), Truth in Lending trigger terms (APR), NCUA insurance statement, prescreened offers, fair lending targeting, UDAAP, CAN-SPAM |
| Security | none | anti-phishing design rules and a standard member safety line |
| Output | email copy | email copy plus a "disclosures required" and "compliance flags" field on every email |
| Metrics | open and click benchmarks | behavior-based metrics, holdout groups, open rates treated as directional |

## What's inside

```
cu-lifecycle-emails/
├── SKILL.md                         # Instructions the agent follows
└── references/
    ├── member-journeys.md           # 10 journey templates + lifecycle audit checklist
    ├── compliance-guardrails.md     # Advertising rules + 10-point pre-send checklist
    └── copy-guidelines.md           # Tone, AI tells to avoid, personalization, testing
```

## How to use it

**Claude app (web, desktop):** download this folder as a ZIP, then go to **Customize → Skills → + Create skill → Upload a skill**. Code execution must be enabled.

**Claude Code:** copy the folder into `~/.claude/skills/` or your project's `.claude/skills/`.

Then ask naturally, for example:
- "Build a 90-day onboarding journey for members who joined through an indirect auto loan."
- "Audit our lifecycle program against the checklist and list the gaps."
- "Review this certificate promo email for compliance flags."

## Important

This skill helps draft and review marketing. It is not legal advice. Every email that advertises an account or credit product should go through your institution's compliance review before it's sent.

## Credits and license

Adapted from the `emails` skill (v2.1.3) in [coreyhaines31/marketingskills](https://github.com/coreyhaines31/marketingskills) by Corey Haines. MIT licensed; see [LICENSE](LICENSE).

Adapted by Mark Nickerson.
