# Credit Union Marketing Ideas by Category

Each idea is tagged:
- **Goal:** Acquire (new members), Deepen (more products, primary relationship), Retain, Brand, Deposits, Loans
- **Cost:** $ (mostly staff time), $$ (modest budget), $$$ (significant budget)
- **Effort:** Low, Med, High
- **⚑** = needs compliance review before launch (rates, offers, credit, targeting, consent, partner data)

## Contents
- Member acquisition and eligibility (1-8)
- Onboarding and digital adoption (9-16)
- Primary relationship and deposits (17-24)
- Lending (25-33)
- Employers and partners (34-41)
- Community and events (42-48)
- Financial education and content (49-56)
- Referrals and advocacy (57-61)
- Students, young adults, and families (62-68)
- Retention and reactivation (69-74)
- Local search, web, and reviews (75-81)
- Paid media (82-87)
- Social and creators (88-93)
- PR and reputation (94-97)
- Branches and physical presence (98-102)
- Small business (103-107)
- Data and personalization (108-112)
- Mergers, rebrands, and big moments (113-116)

---

## Member acquisition and eligibility (1-8)
1. **"Can I join?" eligibility checker** on the website that answers in three questions and routes to account opening. Acquire · $$ · Med
2. **Rewrite the "Who can join" page** in plain language with the easiest path first (for example a low-cost association membership). Acquire · $ · Low
3. **Two-minute account opening audit**: time it, count the steps, fix the worst one. Acquire · $ · Med
4. **Account switching kit** (pre-filled direct deposit form, autopay checklist, close-old-account letter). Acquire · $ · Low
5. **New-to-area welcome program** for people moving into the footprint (real estate partners, apartment complexes, relocation teams). Acquire · $$ · Med
6. **Family-member eligibility campaign** asking members to bring in relatives who already qualify. Acquire · $ · Low ⚑
7. **Bank fee comparison page** showing common big-bank fees versus yours, with substantiation. Acquire · $ · Med ⚑
8. **Branch "join today" event days** with same-day debit card and app setup. Acquire · $$ · Med

## Onboarding and digital adoption (9-16)
9. **90-day new member journey** with milestone-based triggers (see cu-lifecycle-emails). Deepen · $ · Med
10. **App setup in the branch**: staff help every new member download and sign in before they leave. Deepen · $ · Low
11. **First-30-days welcome call** for members who joined through a loan or partner channel. Deepen · $$ · Med
12. **"Three settings to turn on" card** (alerts, card controls, e-statements) in welcome kits and the app. Deepen · $ · Low
13. **Video walkthroughs** of the 5 most common app tasks, linked from onboarding emails. Deepen · $$ · Med
14. **In-app milestone checklist** that shows new members their progress. Deepen · $$ · High
15. **Digital wallet push** right after card activation. Deepen · $ · Low
16. **Indirect auto loan welcome series** that turns dealer-sourced borrowers into full members. Deepen · $ · Med

## Primary relationship and deposits (17-24)
17. **Direct deposit campaign** with a switching tool and clear benefits (early pay if offered). Deepen · $$ · Med ⚑
18. **Checking bonus tied to direct deposit**, with full bonus disclosures and a cap. Acquire · $$$ · Med ⚑
19. **Round-up savings or automatic savings** promotion for members without a savings habit. Deposits · $ · Low
20. **Certificate maturity retention program** that reaches members before the grace period ends. Deposits · $ · Med ⚑
21. **Relationship rate tiers** (better rates for members with direct deposit or multiple products). Deepen · $$ · High ⚑
22. **Emergency savings challenge** (save $500 in 10 weeks) with milestone emails. Deposits · $ · Low
23. **Tax refund season savings push** (February to April). Deposits · $ · Low
24. **Dividend or member-value statement** showing what membership returned to each member this year. Brand · $$ · High ⚑

## Lending (25-33)
25. **Auto loan refinance check** ("See if you could pay less") for members with an external auto payment, using general terms. Loans · $ · Med ⚑
26. **Pre-shopping auto pre-qualification** before members visit a dealer. Loans · $$ · Med ⚑
27. **First-time homebuyer workshop series** with real estate partners. Loans · $$ · Med ⚑
28. **Credit builder loan** or secured card program marketed through community partners. Loans · $$ · Med ⚑
29. **Small-dollar loan alternative to payday lending** promoted through employers. Loans · $ · Med ⚑
30. **Student loan refinance** education for recent graduates. Loans · $ · Low ⚑
31. **Home equity for home improvement** campaign in spring. Loans · $$ · Med ⚑
32. **Loan payoff "what's next" journey** that celebrates and redirects the old payment to savings. Retain · $ · Low
33. **Dealer relationship refresh** with co-branded welcome materials for indirect members. Loans · $$ · Med ⚑

## Employers and partners (34-41)
34. **Employer benefits partnership** with orientation sessions and payroll direct deposit (see cu-partner-programs). Acquire · $ · Med ⚑
35. **Financial wellness lunch-and-learn series** for partner employers. Acquire · $ · Med
36. **Benefits fair presence** with on-the-spot eligibility and account opening. Acquire · $$ · Med
37. **Association member benefit listing** with a dedicated landing page. Acquire · $ · Low
38. **Partner-specific landing pages** with partner co-branding and source tracking. Acquire · $ · Low ⚑
39. **HR toolkit** (newsletter blurbs, intranet copy, posters) partners can drop in. Acquire · $ · Low
40. **Quarterly partner health review** to focus staff time on partners that produce. Acquire · $ · Low
41. **Fintech partnership** that fills a digital gap (switching, budgeting, credit building). Deepen · $$$ · High ⚑

## Community and events (42-48)
42. **Signature community cause** the credit union is known for, with consistent annual presence. Brand · $$ · Med
43. **Shred day or free document shredding** event (also a fraud-awareness moment). Brand · $ · Low
44. **Youth sports and school sponsorships** with financial literacy tie-ins. Brand · $$ · Low
45. **Local business spotlight series** featuring member-owned businesses (with permission). Brand · $ · Low
46. **Volunteer hours program** reported publicly. Brand · $ · Low
47. **Community grants** with member voting. Brand · $$ · Med
48. **Fraud and scam awareness sessions** at senior centers and libraries. Brand · $ · Low

## Financial education and content (49-56)
49. **Plain-language money guides** for life moments (first car, first home, new baby, retirement). Brand · $ · Med
50. **Scam alert content** published fast when a new scam targets members. Retain · $ · Low
51. **Monthly money tip email or text** for members who opt in. Retain · $ · Low
52. **Calculators** (auto payment, savings goal, debt payoff) with no rate claims or with disclosed rates. Acquire · $$ · Med ⚑
53. **Q&A content answering what members ask branches** (from frontline staff). Brand · $ · Low
54. **Short video series with your own staff** explaining one money topic each. Brand · $$ · Med
55. **Financial counseling or coaching** offered free to members. Retain · $$ · High
56. **Teen and young adult money course** delivered with schools. Brand · $ · Med

## Referrals and advocacy (57-61)
57. **Member-get-member program** tied to direct deposit (see cu-member-referrals). Acquire · $$ · Med ⚑
58. **Staff referral program** with clear rules. Acquire · $ · Low ⚑
59. **Member story program** featuring real members (with written consent). Brand · $ · Med
60. **Review request after positive moments** (loan funded, issue resolved). Brand · $ · Low
61. **Member ambassador group** of engaged members who give feedback and share news. Brand · $ · Med

## Students, young adults, and families (62-68)
62. **First paycheck kit** for new workers (direct deposit, budgeting, first card). Acquire · $ · Low
63. **College and trade school partnerships** with campus presence. Acquire · $$ · Med
64. **Teen checking with parent controls**, marketed to parents who are members. Deepen · $ · Low ⚑
65. **Back-to-school savings push** (August). Deposits · $ · Low
66. **Graduation milestone journey** (student checking to adult checking, first credit card education). Retain · $ · Low ⚑
67. **New parent savings account** for children of members. Deepen · $ · Low
68. **Creator partnerships for young adult audiences** with endorsement disclosures. Acquire · $$ · Med ⚑

## Retention and reactivation (69-74)
69. **Stopped direct deposit check-in**, service-style, not sales (see cu-member-retention). Retain · $ · Low
70. **Relationship health score** to prioritize outreach. Retain · $ · Med
71. **Closure exit survey** with monthly reason reporting. Retain · $ · Low
72. **Inactive member reactivation** journey before dormancy rules apply. Retain · $ · Med
73. **Member anniversary message** with a useful tip or benefit. Retain · $ · Low
74. **Fee refund review** for members who regularly pay overdraft fees, with counseling offers. Retain · $$ · Med ⚑

## Local search, web, and reviews (75-81)
75. **Google Business Profile cleanup** for every branch (hours, photos, services, holiday hours). Acquire · $ · Low
76. **Branch landing pages** with local details and services. Acquire · $ · Med
77. **Rates page refresh** with "as of" dates, APY and APR, and clear disclosures. Acquire · $ · Low ⚑
78. **Answer-style content for AI search** ("Can I join [CU] if I live in [town]?"). Acquire · $ · Med
79. **Review response program** (respond to every review; move account issues offline). Brand · $ · Low
80. **Website accessibility audit** and fixes. Brand · $$ · Med
81. **Account opening page speed and mobile fixes.** Acquire · $$ · Med

## Paid media (82-87)
82. **Search ads on high-intent terms** ("auto loan refinance [city]") using the correct special ad categories. Loans · $$ · Med ⚑
83. **Geo-fenced awareness around branches** for brand campaigns (not for credit targeting by ZIP). Brand · $$ · Med ⚑
84. **Streaming audio and connected TV** for local reach. Brand · $$$ · Med ⚑
85. **Always-on brand presence** rather than only campaign bursts. Brand · $$ · Med
86. **Retargeting site visitors who started an application** (within platform rules for credit). Acquire · $$ · Med ⚑
87. **Holdout-tested paid campaigns** so incrementality is measured (see cu-journey-measurement). Acquire · $ · Med

## Social and creators (88-93)
88. **Staff-led social content** (faces people recognize from the branch). Brand · $ · Low
89. **Scam warnings on social** the day a scam hits. Retain · $ · Low
90. **Community event coverage** with member photos (with consent). Brand · $ · Low
91. **Local creator partnerships** with clear disclosures and approved talking points. Acquire · $$ · Med ⚑
92. **LinkedIn presence for employer partnerships** (HR and benefits audiences). Acquire · $ · Low
93. **Social listening for service issues** and fast handoff to member service. Retain · $ · Low

## PR and reputation (94-97)
94. **Local media expert program**: a staff member who comments on rates, scams, and money tips. Brand · $ · Low
95. **Annual community impact report.** Brand · $$ · Med ⚑
96. **Award and ranking submissions** (with dates tracked for substantiation). Brand · $ · Low ⚑
97. **Crisis and outage communication plan** prepared in advance. Retain · $ · Med

## Branches and physical presence (98-102)
98. **Branch merchandising refresh** around one priority product at a time. Deepen · $$ · Low ⚑
99. **Universal banker conversations** guided by member needs, not quotas. Deepen · $ · Med
100. **Digital help desk in branches** for app setup and switching. Deepen · $ · Low
101. **Branch events tied to life moments** (homebuyer night, small business morning). Acquire · $ · Med
102. **ATM and drive-up screen messaging** for current campaigns. Deepen · $ · Low ⚑

## Small business (103-107)
103. **Member-owned business directory** promoted to members. Brand · $ · Med
104. **Small business banking workshops** with local chambers. Acquire · $ · Med
105. **Business account switching kit.** Acquire · $ · Low
106. **Employee benefits offer** for small businesses that bank with you. Acquire · $ · Med ⚑
107. **Merchant services or payroll partner** co-marketing. Deepen · $$ · High ⚑

## Data and personalization (108-112)
108. **Next-best-product model** based on held products and life stage (no protected characteristics). Deepen · $$ · High ⚑
109. **Suppression rules** (collections, fraud cases, complaints) across all marketing. Retain · $ · Med
110. **Frequency cap across journeys** so members aren't over-messaged. Retain · $ · Low
111. **Join-channel tracking** (branch, digital, dealer, partner, referral) on every new account. Acquire · $ · Med
112. **Member preference center** for topics and channels. Retain · $$ · Med

## Mergers, rebrands, and big moments (113-116)
113. **Merger reassurance journey** (what changes, what doesn't, when, who to call). Retain · $$ · High ⚑
114. **Distinctive brand assets audit** (colors, sounds, characters) used consistently everywhere. Brand · $ · Med
115. **"Why we're different" member-owner story** told consistently across channels. Brand · $ · Med
116. **Annual meeting turned into a member engagement moment** (live stream, Q&A, results). Brand · $ · Med
