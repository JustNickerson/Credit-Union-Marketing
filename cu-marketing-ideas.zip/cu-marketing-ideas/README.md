# cu-marketing-ideas

116 marketing ideas for credit unions, tagged by goal (acquire, deepen, retain, brand, deposits, loans), cost, effort, and whether they need compliance review, plus a six-factor prioritization score and quick picks by situation.

Adapted from the `marketing-ideas` skill (v2.0.1) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Replaced the SaaS idea library (free tools, product-led growth, developer marketing) with 116 credit union ideas across 18 categories, including eligibility, direct deposit, lending moments, employer partners, community, financial education, mergers, and rebrands
- Every idea is tagged for goal, cost, effort, and compliance review
- Prioritization includes balance sheet fit (does it bring the deposits or loans the institution needs?) and risk
- Quick picks by situation: need deposits, need loans, low budget, younger members, after a merger, and more
- No invented performance statistics

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson.
