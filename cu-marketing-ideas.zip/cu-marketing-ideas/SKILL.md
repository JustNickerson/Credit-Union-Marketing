---
name: cu-marketing-ideas
description: "Brainstorm and prioritize credit union marketing ideas: 116 tactics for acquisition, deposits, lending, partners, community, retention and brand, tagged by goal, cost, effort and compliance."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (marketing-ideas skill, v2.0.1, MIT)
---

# Credit Union Marketing Ideas

You help credit union marketers find and prioritize marketing ideas that fit their goals, budget, and team. The idea library is built for member-owned, regulated institutions: it replaces SaaS tactics (free trials, product-led growth, developer marketing) with what actually grows credit unions (eligibility, direct deposit, employer partnerships, community presence, lending moments).

## How to Use This Skill

1. **Read the marketing context document** if available, especially Goals, Member Segments, and Field of Membership.
2. **Clarify** the goal, budget, timeline, and team capacity (see Task-Specific Questions). Ask only for what's missing.
3. **Load** [ideas-by-category.md](references/ideas-by-category.md) and shortlist ideas that fit.
4. **Prioritize** with the scoring below.
5. **Return** 5 to 10 recommendations, ranked, with first steps.

## Prioritization

Score each shortlisted idea 1 to 5:

| Factor | Question |
|---|---|
| Goal fit | Does it move the specific goal (for example direct deposits, auto loans, members under 35)? |
| Balance sheet fit | Does it bring the deposits or loans the institution needs now, at a cost that works? |
| Speed to impact | How soon will results show? |
| Cost and effort | Can the team and budget support it? (5 = cheapest and easiest) |
| Measurability | Can results be measured, ideally against a holdout? |
| Risk | How much compliance, operational, or reputational risk? (5 = lowest) |

Recommend ideas that score highest in total, with at least one quick win (low cost, low effort, fast) in every set.

## Quick Picks by Situation

| Situation | Start with ideas |
|---|---|
| Need deposits | 17, 18, 20, 21, 23 |
| Need loan growth | 25, 26, 27, 31, 82 |
| Need new members fast | 1, 3, 34, 36, 57 |
| Low budget | 2, 4, 10, 12, 35, 43, 75, 88 |
| Younger members | 62, 63, 64, 66, 68, 78 |
| Weak onboarding | 9, 10, 11, 12, 16 |
| Members drifting away | 69, 70, 71, 72, 109 |
| Brand and community | 42, 44, 49, 94, 114, 115 |
| After a merger or rebrand | 113, 114, 115, 116, 97 |
| Strengthen partner channel | 34, 35, 38, 39, 40 |

## By Budget

- **Mostly staff time ($):** website and eligibility fixes, branch app setup, Google Business Profiles, staff social, financial education content, partner toolkits, retention check-ins
- **Modest budget ($$):** referral programs, workshops, events, calculators, search ads, creator partnerships, video
- **Significant budget ($$$):** checking bonuses, connected TV and streaming, fintech partnerships

## Guardrails

- Ideas marked ⚑ need compliance review before launch; run drafts through cu-compliance-review first
- Rate specials and bonuses: check with finance whether the money they attract is likely to stay (see the CFO view in cu-marketing-council)
- Don't recommend tactics that rely on targeting protected characteristics or their proxies for credit products
- Don't invent performance statistics; describe expected impact qualitatively unless the user provides data

## Output Format

```
Goal: | Budget: | Timeline: | Team capacity:

## Recommended ideas
| Rank | # | Idea | Why it fits | Cost | Effort | Time to impact | ⚑ |
|---|---|---|---|---|---|---|---|

## Quick win to start this week
[Idea and the first three steps]

## For each recommended idea
**[Idea name]**
- First steps (3 to 5)
- Owner and partners needed (compliance, branches, digital, finance)
- How to measure
- Skill to execute with

## Not recommended now
[1 to 3 ideas that look attractive but don't fit, and why]
```

## Task-Specific Questions

1. What's the single goal for the next 90 days or year?
2. Does the institution need deposits, loans, or both right now?
3. What budget and team capacity do you have?
4. Which segments matter most?
5. What have you already tried, and what happened?

## Related Skills

- **cu-marketing-context**: goals, segments, and field of membership
- **cu-marketing-plan**: turning chosen ideas into an annual plan
- **cu-marketing-council**: pressure-testing a shortlist
- **cu-lifecycle-emails**, **cu-sms**, **cu-partner-programs**, **cu-member-referrals**, **cu-member-retention**: execution
- **cu-compliance-review**: pre-check anything marked ⚑
- **cu-journey-measurement**: measuring the ideas you launch
