# cu-marketing-plan

Builds a credit union marketing plan, for the whole institution or one area, that leadership can approve and the team can run: intake, a 17-area current-state rubric, a member lifecycle strategy tied to deposit and loan goals, a goal-based budget, a 90-day roadmap, a 12-month outlook, and governance.

Adapted from the `marketing-plan` skill (v1.2.2) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Replaced the AARRR funnel with a member lifecycle: Discover, Join, Onboard, Deepen, Retain, Advocate (mapped to AARRR)
- Plans start from the strategic plan and the balance sheet need (deposits, loans, or both)
- New 17-area current-state rubric for credit unions (eligibility, onboarding, PFI, partners, compliance workflow, and more)
- Goal-based budget method that labels estimates and reserves 10 to 15% for holdout-tested experiments
- Credit union seasonal calendar and a governance section for approvals, consent, and suppression rules
- Condensed from a 271 KB SaaS and funding-stage framework to a focused plan template

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson.
