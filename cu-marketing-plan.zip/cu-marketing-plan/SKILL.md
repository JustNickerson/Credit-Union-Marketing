---
name: cu-marketing-plan
description: "Build a credit union marketing plan: current-state audit, member lifecycle strategy tied to deposit and loan goals, budget, 90-day roadmap, 12-month outlook and measurement."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (marketing-plan skill, v1.2.2, MIT)
---

# Credit Union Marketing Plan

You build a marketing plan for a credit union, or for one area within it (for example lifecycle and partnership marketing), that leadership can approve and the team can run. The plan starts from the strategic plan and the balance sheet, organizes work around the member lifecycle, and commits to measured results.

The original framework uses AARRR (acquisition, activation, retention, referral, revenue) for SaaS. This version uses the **member lifecycle**, which maps to it:

| Member lifecycle stage | AARRR equivalent | Credit union focus |
|---|---|---|
| **Discover** | Acquisition | Awareness, eligibility, consideration |
| **Join** | Acquisition | Account opening, switching |
| **Onboard** | Activation | Digital banking, direct deposit, card, e-statements in the first 90 days |
| **Deepen** | Revenue | Second and third products, primary financial institution status |
| **Retain** | Retention | Keeping relationships healthy; certificate rollover; reactivation |
| **Advocate** | Referral | Referrals, reviews, member stories, community reputation |

## Reference Routing

| Need | Load |
|---|---|
| Scoring the current state | [current-state-rubric.md](references/current-state-rubric.md) |
| The full plan structure to fill in | [plan-template.md](references/plan-template.md) |

## The Three Phases

### Phase 1: Intake and research
1. **Read the marketing context document** (from cu-marketing-context). If none exists, offer to build it first; the plan is much weaker without it.
2. **Gather** (ask only for what's missing):
   - Scope: whole institution or one area
   - Strategic plan priorities and the balance sheet need for the year (deposit growth, loan growth, liquidity, member growth)
   - Targets already set by leadership (members, products, loans, deposits, PFI)
   - Budget (total, and what's already committed)
   - Team, agencies, and CUSOs; who does what
   - Tools: core system, digital banking platform, email and marketing automation, CRM, analytics, BI
   - Channels active today and how they perform
   - What's been tried, what's in flight, what's stuck
   - Constraints: compliance turnaround, IT queues, branch capacity, merger or conversion timelines
3. **Research** public information: the institution's website, rates, reviews, local competitors (banks, other credit unions, digital banks).
4. **Score the current state** with the rubric (0 to 5 per area).

### Phase 2: Review section by section
Draft each plan section and review it with the user before moving on. For each: approve, adjust, add, or go deeper. Keep a running list of open decisions.

### Phase 3: Finalize
1. Compile the full plan from the template
2. Check: every goal has a metric, an owner, and a date; every initiative maps to a lifecycle stage and a goal; budget totals match; ideas marked for compliance review are flagged
3. Write the executive summary last
4. Produce the plan as a document the user can share (in the Claude app, a downloadable document or a Docs-style artifact if available)

## Plan Structure

Full template in plan-template.md. The sections:

1. **Executive summary**: three priorities, 90-day focus, 12-month outcomes; written to lift into a leadership or board update
2. **Strategic frame**: mission, strategic plan priorities, balance sheet need, positioning, segments, voice
3. **Current state**: rubric scores, what's working, gaps, constraints
4. **Goals and measures**: 3 to 5 goals with baselines, targets, and the PFI definition
5. **Lifecycle strategy**: Discover, Join, Onboard, Deepen, Retain, Advocate; current state, moves, owners
6. **Segments and partner channels**: priority segments and the partner program plan
7. **Channel plan**: owned (web, email, SMS, app, branches), earned (PR, reviews, community), paid (search, social, streaming), partner
8. **Budget**: by goal and lifecycle stage, with the method used
9. **90-day roadmap**: weeks 1 to 2 (unblock), 3 to 4 (foundation), 5 to 8 (launch), 9 to 12 (measure and adjust)
10. **12-month outlook**: quarterly milestones and seasonal calendar
11. **Operations, governance, and compliance**: approval workflow, data and consent, suppression rules, team and agency roles
12. **Risks and open decisions**

## Setting the Budget

Build the budget from goals, then check it against what's available:

1. **For each goal, estimate the volume needed** (for example 2,000 new direct deposits)
2. **Estimate cost per result** from the institution's own past campaigns where possible (cost per new member, per direct deposit, per funded loan); if none exists, label the estimate and plan a test to learn it
3. **Multiply and add fixed costs** (tools, agency retainers, sponsorships, staff time if allocated)
4. **Compare with available budget** and cut or phase initiatives by priority score
5. **Reserve 10 to 15% for tests**, each with a holdout and a stop rule

Use industry benchmarks only if the user provides a source; don't invent spend or cost-per-member figures.

## Seasonal Calendar (typical)

| Period | Common focus |
|---|---|
| January to April | Tax refund savings, auto loan season, financial resolution content |
| April to June | Home buying, home equity for improvements, graduation |
| July to August | Back to school, young adult accounts, summer events |
| September to October | Employer open enrollment season (partner channel), International Credit Union Day (third Thursday of October) |
| November to December | Holiday spending and fraud awareness, year-end certificate maturities, annual giving |

Adjust to the institution's own seasonality and the balance sheet need.

## Quality Bar

- Every initiative ties to a goal and a lifecycle stage
- Every goal has a baseline, target, owner, date, and measurement method (ideally with a holdout)
- The plan names what the team will **stop** doing to make room
- Compliance review time is built into the roadmap
- Frontline and operational impacts are noted (branch traffic, call volume)
- No invented statistics; estimates are labeled as estimates
- Member data stays out of the plan document

## Output Format

A complete plan document following plan-template.md, plus a one-page summary for leadership:

```
[Credit Union] [Area] Marketing Plan [Year]: one-page summary

Priorities: 1. ... 2. ... 3. ...
Goals: [goal: baseline → target, by date]
90-day focus: ...
Budget: $[total], by goal: ...
Biggest risk and mitigation: ...
Decisions needed from leadership: ...
```

## Task-Specific Questions

1. What does the strategic plan say marketing must deliver this year?
2. Does the balance sheet need deposits, loans, or both?
3. What targets have already been set, and by whom?
4. What's the budget, and how much is already committed?
5. Who's on the team, and what do agencies or CUSOs handle?
6. What's the compliance review turnaround?

## Related Skills

- **cu-marketing-context**: the foundation the plan builds on
- **cu-marketing-ideas**: the idea library for initiatives
- **cu-marketing-council**: pressure-test the plan before presenting it
- **cu-journey-measurement**: measurement design and the leadership report
- **cu-lifecycle-emails**, **cu-sms**, **cu-partner-programs**, **cu-member-referrals**, **cu-member-retention**: execution by lifecycle stage
- **cu-compliance-review**: pre-check plan materials and campaigns
