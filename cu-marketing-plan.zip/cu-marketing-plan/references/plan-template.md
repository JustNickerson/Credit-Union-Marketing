# Marketing Plan Template

Fill each section. Delete guidance text in brackets when done. Label estimates as estimates.

```markdown
# [Credit Union] [Area] Marketing Plan: [Year]

**Prepared by:** [Name, title] · **Date:** YYYY-MM-DD · **Version:** v1
**Scope:** [Whole institution / area]

---

## 1. Executive summary
**The year in one sentence:** [What marketing will deliver and why it matters to the strategic plan]

**Three priorities**
1. [Priority: outcome, by when]
2.
3.

**90-day focus:** [The few things that happen first]

**12-month outcomes**
| Goal | Baseline | Target | Date |
|---|---|---|---|
| | | | |

**Budget:** $[total] · **Decisions needed:** [list]

---

## 2. Strategic frame
**Mission and strategic plan priorities:**
**Balance sheet need this year:** [deposits / loans / both; from finance]
**Positioning:** [from the marketing context document]
**Priority segments:**
**Brand voice non-negotiables:**

---

## 3. Current state
**Rubric summary** (see current-state rubric)
| Area | Score | Evidence | Priority |
|---|---|---|---|

**What's working:**
**Biggest gaps:**
**Constraints:** [compliance turnaround, IT, branch capacity, merger timeline, budget]

---

## 4. Goals and measures
**PFI definition:**

| Goal | Metric | Baseline | Target | Owner | Measurement method |
|---|---|---|---|---|---|
| | | | | | [holdout / cohort / staggered] |

---

## 5. Lifecycle strategy

For each stage: current state, the 2 to 4 moves this year, owner, skill to execute with.

### Discover
### Join
### Onboard
### Deepen
### Retain
### Advocate

---

## 6. Segments and partner channels
| Segment | Goal | Key message | Channels | First moves |
|---|---|---|---|---|

**Partner program plan:** [priority partners, targets, review cadence]

---

## 7. Channel plan
| Channel | Role in the plan | Current state | This year's moves | Metric |
|---|---|---|---|---|
| Website and account opening | | | | |
| Email | | | | |
| SMS | | | | |
| App and digital banking | | | | |
| Branches and contact center | | | | |
| Partners and employers | | | | |
| Community and events | | | | |
| PR and reviews | | | | |
| Paid search | | | | |
| Paid social | | | | |
| Streaming, audio, TV | | | | |

**What we will stop doing:**

---

## 8. Budget
**Method:** [goal-based build: volume × cost per result + fixed costs; estimates labeled]

| Goal / stage | Initiatives | Est. volume | Est. cost per result | Budget | Notes |
|---|---|---|---|---|---|
| | | | | | |
| Fixed costs (tools, agency, sponsorships) | | | | | |
| Test reserve (10 to 15%) | | | | | |
| **Total** | | | | | |

---

## 9. 90-day roadmap
| Weeks | Theme | Initiatives | Owner | Lifecycle stage | Done when |
|---|---|---|---|---|---|
| 1 to 2 | Unblock | | | | |
| 3 to 4 | Foundation | | | | |
| 5 to 8 | Launch | | | | |
| 9 to 12 | Measure and adjust | | | | |

---

## 10. 12-month outlook
| Quarter | Milestones | Seasonal focus | Review point |
|---|---|---|---|
| Q1 | | | |
| Q2 | | | |
| Q3 | | | |
| Q4 | | | |

---

## 11. Operations, governance, and compliance
**Approval workflow and turnaround:**
**Pre-approved language and templates:**
**Consent and data:** [email, SMS, partner data, suppression rules]
**Team, agencies, and CUSOs:**
| Role | Owner | Responsibilities |
|---|---|---|

**Reporting cadence:** [monthly one-page report; quarterly leadership review]

---

## 12. Risks and open decisions
| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|

| Open decision | Options | Needed from | By |
|---|---|---|---|

---

## Changelog
- v1 (YYYY-MM-DD): Initial plan.
```
