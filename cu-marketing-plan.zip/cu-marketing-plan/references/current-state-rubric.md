# Current-State Rubric

Score each area 0 to 5 from available materials and interviews. Note the evidence for each score. Areas scoring 0 to 2 are candidates for the 90-day roadmap.

**Scale:** 0 = absent · 1 = ad hoc · 2 = basic, inconsistent · 3 = in place and working · 4 = measured and improving · 5 = best in class, measured against a holdout

| # | Area | What a 3 looks like | What a 5 looks like |
|---|---|---|---|
| 1 | **Marketing context and positioning** | A written positioning and context document exists | Kept current, versioned, used by every team and agency |
| 2 | **Goals tied to the strategic plan** | Marketing goals exist and relate to the plan | Goals map to balance sheet needs with baselines, targets, and owners |
| 3 | **Eligibility and joining** | Eligibility is explained; account opening works online | Eligibility answered in seconds; account opening is fast, mobile-first, and measured by step |
| 4 | **Onboarding (first 90 days)** | A welcome series exists | Milestone-triggered journey with exits, measured against a holdout |
| 5 | **Primary relationship** | Direct deposit is promoted | PFI defined, tracked, and grown deliberately |
| 6 | **Cross-sell and deepening** | Product campaigns run | Needs-based next-product journeys using member behavior, measured |
| 7 | **Retention** | Closures are tracked | Early-warning signals drive outreach; exit reasons reported monthly |
| 8 | **Referrals and advocacy** | A referral program or review requests exist | Referral program tied to relationship behavior; reviews managed; member stories |
| 9 | **Partner and employer programs** | Partners exist | Partners scored, tracked by source, reviewed quarterly |
| 10 | **Community and brand** | Sponsorships and events happen | A consistent signature cause; distinctive brand assets; impact reported |
| 11 | **Owned channels** | Website, email, and app messaging in use | Coordinated across channels with frequency caps and a preference center |
| 12 | **Paid media** | Some paid campaigns | Always-on plus campaigns, correct ad categories, incrementality measured |
| 13 | **Local search and reviews** | Branch listings exist | Listings complete and current; reviews answered; local pages per branch |
| 14 | **Data and segmentation** | Basic segments in use | Join channel, product holdings, and behaviors drive journeys; suppression rules in place |
| 15 | **Measurement and reporting** | Campaign reports exist | Lifecycle metrics, holdouts, and a regular one-page leadership report |
| 16 | **Compliance workflow** | Marketing is reviewed before launch | Pre-approved language, templates, and predictable turnaround |
| 17 | **Team, agencies, and tools** | Roles are known | Clear ownership; tools integrated; agencies measured on outcomes |

## Summary table for the plan

| Area | Score | Evidence | Priority (Now / Next / Later) |
|---|---|---|---|
| | | | |
