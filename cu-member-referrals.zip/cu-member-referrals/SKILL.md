---
name: cu-member-referrals
description: "Design, launch and optimize credit union member-get-member referral programs: eligibility, rewards and bonus disclosures, fraud controls, messaging and measurement."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (referrals skill, v2.2.1, MIT)
---

# Credit Union Member Referral Programs

You help credit unions turn satisfied members into a growth channel. Word of mouth is how most people end up at a credit union; a well-run referral program makes it easier to act on and measurable. It also carries real traps: membership eligibility, bonus disclosure rules, tax reporting, and bonus abuse.

## Before Starting

**Read the marketing context document** if available, especially Field of Membership and Approved Claims. Then understand:

1. **Goal**: new members overall, a segment (young adults, families), or a product (checking with direct deposit, auto loans)
2. **Current state**: is there a program today, and how does it perform?
3. **Systems**: can account opening capture a referral code or link? Can bonuses be paid and tracked automatically?
4. **Budget**: reward amount per side and annual cap
5. **Approvals**: compliance, finance (tax reporting), fraud or risk

## Program Design

### 1. Eligibility
- **Referrer**: a member in good standing (define it: for example, account open 90+ days, not delinquent, not charged off)
- **Referred person**: must be eligible for membership under your field of membership, new to the credit union (define "new," for example no account in the last 12 months), and meet the qualifying action
- Decide whether employees, their households, and existing joint owners can participate

### 2. Qualifying action
Tie the reward to a behavior that signals a real relationship, not just an account opening:
- Opening checking **and** receiving a qualifying direct deposit within 60 to 90 days (strongest)
- Opening checking and making a set number of debit transactions
- A funded consumer loan (needs compliance review; see guardrails below)

### 3. Rewards
| Structure | Notes |
|---|---|
| Two-sided cash deposit (for example $50 each) | Most common; easy to understand |
| Higher reward for the referred member | Drives conversion; referrer reward can be smaller |
| Charitable donation option | Fits member-owned values; some members prefer it |
| Tiered (more referrals, bigger reward) | Use an annual cap to control cost and abuse |

Set an annual cap per referrer (for example 5 to 10 rewards per year).

### 4. Trigger moments to ask
Ask right after members feel good about you:
- After a positive milestone (direct deposit set up, loan funded, first certificate opened)
- After a high satisfaction or NPS response
- At account anniversary
- In the app after a successful mobile deposit or transfer
- From branch staff after a helpful interaction (referral cards with a code)

### 5. Share mechanisms
- Personal referral link or code in digital banking
- Pre-written messages members can edit (text, email, social)
- Printable or digital referral cards for branches and events
- Make the referred person's landing page explain eligibility first; ineligible referrals are the biggest source of frustration

## Guardrails

- **Deposit bonuses are advertised terms.** A bonus for opening a share or checking account must disclose the bonus amount, the qualifying requirements, any minimum balance, when the bonus is paid, and the offer end date (Truth in Savings). Use APY terms correctly if rates are mentioned.
- **Tax reporting.** Bonuses and rewards may be reportable income for members (for example on a 1099-INT or 1099-MISC depending on how they are paid and the amount). Confirm treatment with finance before launch, and say in the terms that rewards may be reportable.
- **No rewards for mortgage referrals without compliance review.** RESPA Section 8 restricts giving anything of value for referrals of settlement business. Most programs exclude mortgage and home equity from referral rewards.
- **Loan-based rewards** need compliance review, must not imply approval, and must apply consistently.
- **Equal treatment.** Apply eligibility and rewards consistently; don't vary rewards by protected characteristics.
- **Privacy.** The referrer shouldn't learn whether their friend joined beyond what the friend agreed to share; a reward notice ("Your reward has been paid") is enough.
- **Approvals.** Run program terms and every promotional piece through cu-compliance-review and then your compliance team.

## Fraud and Abuse Controls

- Annual cap per referrer
- Qualifying direct deposit or activity requirement, not just account opening
- Minimum time the new account must stay open, with a clawback or forfeiture clause in the terms
- Duplicate detection (same address, phone, device, or funding source)
- Exclude self-referrals and existing joint owners
- Review unusual patterns monthly (one referrer with many referrals in a short time)

## Program Terms Outline

1. Program name, sponsor, start and end dates
2. Referrer eligibility
3. Referred member eligibility, including membership eligibility
4. Qualifying actions and deadlines
5. Reward amounts, how and when paid, annual cap
6. Tax reporting statement
7. Exclusions (products, employees, existing members)
8. Fraud, abuse, and forfeiture provisions
9. Right to modify or end the program
10. Contact for questions

## Messaging

**Launch email to existing members** (one primary CTA: share your link)
- Subject: Know someone who'd like banking here?
- Lead with why members refer (the experience), then the reward, then how it works in three steps, then full terms

**Referred-person landing page**
- Who can join and how (eligibility first)
- What they get and what they need to do, with full bonus terms
- One action: start an application

**Reward notification**
- Subject: Your referral reward is in your account
- Thank them, state the amount, invite another share

Avoid "Give $50, get $50!" as the only line; a reward without context sounds like a promotion, not a recommendation from a friend.

## Measurement

| Metric | Definition |
|---|---|
| Share rate | Members who shared at least once ÷ members invited to share |
| Referral conversion | Referred people who completed the qualifying action ÷ referred people who started |
| Members acquired | Qualifying new members from referrals |
| Cost per acquired member | Rewards + program costs ÷ members acquired |
| Referred-member quality | Direct deposit rate, products per member at 90 days, 12-month retention vs. other channels |
| Ineligible-referral rate | Started applications that failed eligibility (fix the landing page if high) |

Referred members often stay longer and hold more products than members from paid channels; measure it, because that comparison is what justifies the budget.

## Launch Checklist

- [ ] Eligibility, qualifying action, rewards, and cap defined
- [ ] Terms written and approved by compliance
- [ ] Tax treatment confirmed with finance
- [ ] Referral code or link captured at account opening
- [ ] Automated reward payment and tracking tested end to end
- [ ] Fraud rules configured
- [ ] Landing page explains eligibility first
- [ ] Branch staff briefed with referral cards
- [ ] Launch email, in-app placement, and reward notification approved
- [ ] Reporting dashboard ready

## Output Format

```
Program name:
Goal and target:
Eligibility (referrer / referred):
Qualifying action and deadline:
Rewards and cap:
Trigger moments and share mechanisms:
Fraud controls:
Compliance and tax items:
Messaging plan:
Measurement plan:
```

## Task-Specific Questions

1. What's the one behavior you want referred members to complete?
2. Can account opening capture a referral code today?
3. What reward budget per member and per year do you have?
4. Who handles reward payment and tax reporting?

## Related Skills

- **cu-marketing-context**: field of membership and approved claims
- **cu-partner-programs**: partner channels that complement member referrals
- **cu-lifecycle-emails**: onboarding for referred members
- **cu-compliance-review**: pre-check terms and promotional pieces
- **cu-journey-measurement**: comparing referred-member quality to other channels
