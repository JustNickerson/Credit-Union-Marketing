# cu-member-referrals

Designs member-get-member referral programs with membership eligibility, bonus disclosures, tax reporting, fraud controls, messaging, and measurement.

Adapted from the `referrals` skill (v2.2.1) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Eligibility built around field of membership and members in good standing
- Rewards tied to relationship behaviors such as direct deposit
- Added Truth in Savings bonus disclosure, tax reporting, and RESPA guardrails
- Added fraud and abuse controls and a program terms outline
- Removed affiliate and review-program sections that don't apply to credit unions

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson. Not legal advice; route all marketing through your institution's compliance review.
