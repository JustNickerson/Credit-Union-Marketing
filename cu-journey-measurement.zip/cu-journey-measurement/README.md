# cu-journey-measurement

Measures what credit union lifecycle, partner, referral, and retention programs actually change: a four-level metric hierarchy, one shared primary financial institution (PFI) definition, holdout test design, sample sizes, cohort reporting, and a one-page leadership report.

**This is an original skill**, written for marketers working in Excel and Power BI. The formulas reference includes ready-to-paste Excel formulas for sample size, lift, significance, and confidence ranges, plus a worked example.

Part of [credit-union-marketing-skills](../../README.md). Written by Mark Nickerson. MIT licensed; see [LICENSE](LICENSE).
