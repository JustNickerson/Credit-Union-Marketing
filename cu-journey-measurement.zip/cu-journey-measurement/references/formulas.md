# Measurement Formulas

Plain-language formulas with Excel versions. Assumes a goal measured as a rate (for example, the share of members who set up direct deposit).

## Contents
- Sample size per group
- Lift
- Is the difference real? (two-proportion test)
- Confidence interval for the difference
- Incremental members and value
- Worked example

---

## Sample size per group

A quick, standard rule for 80% power at 95% confidence:

> n per group ≈ 16 × p × (1 − p) ÷ d²

- p = baseline rate (for example 0.30)
- d = the smallest improvement worth detecting, as a proportion (for example 0.05 for 5 points)

**Excel** (baseline in B1, improvement in B2):
```
=ROUNDUP(16*B1*(1-B1)/B2^2, 0)
```

With an unequal split (for example a 10% holdout), the holdout group is the constraint: it needs at least n members, so total volume ≈ n ÷ holdout share.
```
=ROUNDUP(B3/B4, 0)      ' B3 = n per group, B4 = holdout share (0.10)
```

| Baseline | Detect +3 pts | Detect +5 pts | Detect +10 pts |
|---|---|---|---|
| 10% | 1,601 | 576 | 144 |
| 20% | 2,845 | 1,024 | 256 |
| 30% | 3,734 | 1,344 | 336 |
| 50% | 4,445 | 1,600 | 400 |

(Members needed in each group.)

## Lift

> Absolute lift = treatment rate − holdout rate
> Relative lift = (treatment rate − holdout rate) ÷ holdout rate

**Excel** (treatment rate in C1, holdout rate in C2):
```
=C1-C2
=(C1-C2)/C2
```

## Is the difference real? (two-proportion test)

Inputs: treatment successes x1 and size n1; holdout successes x2 and size n2.

**Excel** (x1 in D1, n1 in D2, x2 in D3, n2 in D4):
```
p1:        =D1/D2
p2:        =D3/D4
pooled p:  =(D1+D3)/(D2+D4)
z:         =(D1/D2-D3/D4)/SQRT(((D1+D3)/(D2+D4))*(1-(D1+D3)/(D2+D4))*(1/D2+1/D4))
p-value:   =2*(1-NORM.S.DIST(ABS(z_cell),TRUE))
```

A p-value below 0.05 is the usual threshold for "statistically significant." Decide the threshold and the test window before you look at results.

## Confidence interval for the difference

**Excel** (95%):
```
standard error: =SQRT((D1/D2)*(1-D1/D2)/D2 + (D3/D4)*(1-D3/D4)/D4)
lower:          =(D1/D2-D3/D4) - 1.96*se_cell
upper:          =(D1/D2-D3/D4) + 1.96*se_cell
```

Report the range, not only the point estimate: "Direct deposit rate rose 4.8 points (95% range: 2.1 to 7.5)."

## Incremental members and value

> Incremental members = absolute lift × members who received the program
> Incremental value = incremental members × annual value per goal behavior (from finance)

**Excel** (lift in E1, treated members in E2, annual value in E3):
```
=E1*E2
=E1*E2*E3
```

Use the lower end of the confidence interval for a conservative value estimate.

## Worked example

- New member onboarding journey, goal: direct deposit within 60 days
- Treatment: 12,000 members, 4,080 set up direct deposit (34.0%)
- Holdout: 1,350 members, 405 set up direct deposit (30.0%)
- Absolute lift: 4.0 points; relative lift: 13.3%
- z ≈ 2.95, p-value ≈ 0.003, so the difference is very unlikely to be chance
- 95% range for the lift: roughly 1.4 to 6.6 points
- Incremental direct deposits: 0.04 × 12,000 = 480 (conservative: 0.014 × 12,000 ≈ 170)
- If finance values an active direct deposit relationship at $X per year, incremental value is 480 × $X (conservative: 170 × $X)
