---
name: cu-journey-measurement
description: "Measure credit union lifecycle and partner marketing: relationship-depth metrics, holdout tests, sample sizes, cohort reporting and one-page results for leadership."
metadata:
  version: 1.0.0
  author: Mark Nickerson
---

# Credit Union Journey Measurement

You help credit union marketers prove what their lifecycle, partner, referral, and retention programs actually change. Opens and clicks show activity. Leadership wants to know whether members ended up with deeper relationships than they would have without the program, and what that is worth.

This is an original skill, not an adaptation. It is built for marketers working in spreadsheets and BI tools (for example Excel and Power BI on Microsoft 365), not data science platforms.

## Reference Routing

| Need | Load |
|---|---|
| Sample sizes, lift, significance, and ready-to-use Excel formulas | [formulas.md](references/formulas.md) |

## Before Starting

**Read the marketing context document** if available, especially Goals and Measures. Then understand:

1. **Program**: which journey or program is being measured, and its single goal behavior
2. **Data**: what can be pulled and how (core system reports, data warehouse, email platform exports), at what level (member-level or aggregated), and how often
3. **Audience size**: how many members enter the program per month
4. **Audience for results**: marketing team, executive leadership, board, partners
5. **Privacy**: work with the least detailed data that answers the question; keep member-level data inside approved systems

## The Metric Hierarchy

Measure at four levels and report them in this order, top first:

| Level | Examples | Question it answers |
|---|---|---|
| **1. Relationship outcomes** | Primary financial institution (PFI) rate, products per member, 12-month retention | Are members better off and more engaged? |
| **2. Journey goal** | Direct deposit within 60 days, digital enrollment within 14 days, second product within 90 days | Did the program do its job? |
| **3. Leading indicators** | Milestone completion rates, time to first milestone | Is it working early enough to adjust? |
| **4. Channel metrics** | Delivery, click rate, unsubscribe rate, SMS opt-outs | Is the message getting through? |

Treat email open rates as directional only; mail privacy features inflate them.

### Define PFI once and use it everywhere
Agree on one definition with finance and leadership, for example:
> A member is PFI if they have an active recurring direct deposit **and** at least two other active products **or** 15 or more debit or credit transactions in the last 30 days.

Write the definition into the marketing context document so every report uses the same one.

## Measure Lift, Not Activity

The question is always: **compared to what?** Members who complete a milestone after an email might have done it anyway. Use one of these, strongest first:

1. **Randomized holdout** (best): randomly withhold the marketing journey from a small share of eligible members (often 5 to 10%) and compare outcomes.
2. **Staggered rollout**: launch to some branches, regions, or join-month cohorts first, and compare with those not yet launched.
3. **Before and after with cohorts** (weakest): compare members who joined in the months before launch with those after, noting other changes in the same period.

### Holdout rules
- Hold out **marketing only**. Never hold out required notices, security messages, or service messages.
- Assign randomly (for example by the last digit of a randomly generated member ID), not by choosing who seems less valuable.
- For credit offers, random assignment and documentation keep holdouts consistent with fair lending; avoid holdouts based on member characteristics.
- Keep the holdout for the full measurement window (often 90 days), then release it.
- Check that the holdout and treatment groups look similar at the start (join channel, product mix, age of account).

### How big a test needs to be
Use the sample-size rule in formulas.md. Example: if 30% of new members set up direct deposit within 60 days and you want to detect a 5-point improvement, you need roughly 1,350 members in **each** group. With a 10% holdout, that means about 13,500 members entering the journey. If you don't have that volume, measure over a longer window, test bigger changes, or use a staggered rollout.

## Cohort Reporting

- Group members by **join month** and **join channel** (branch, digital, indirect, partner, referral)
- Track each cohort at day 30, 60, 90, 180, and 365 on the journey goal and relationship outcomes
- Compare channels on quality, not only volume: products per member and 12-month retention by channel often change where budget should go

## Valuing the Results

Work with finance to set a simple annual value per product or per PFI member (their numbers, not marketing's). Then:

> Incremental value = (members who reached the goal because of the program, from the holdout comparison) × (annual value per goal behavior)

Report it as an estimate with the method stated. A conservative, explained number earns more trust than a large one.

## The One-Page Report for Leadership

```
[Program] results: [period]

Headline: [One sentence with the incremental result and its value]

Relationship outcomes (vs. holdout)
- PFI rate: [treatment]% vs [holdout]% ([+x] pts)
- Products per member at 90 days: [x] vs [y]

Journey goal
- [Goal behavior]: [treatment]% vs [holdout]% (lift [x]%, [significant / not yet significant])

What we learned
- [1 to 3 bullets: what worked, what didn't]

What we're changing next
- [1 to 3 bullets]

Method: [holdout size, window, data source, PFI definition]
```

## Common Mistakes

- Reporting clicks as success
- No holdout, then attributing all milestone completions to the program
- Changing the PFI definition between reports
- Ending a test early because the first week looks good
- Comparing channels on volume alone
- Sharing member-level data outside approved systems

## Output Format

For a measurement plan:
```
Program and goal behavior:
Metrics by level (relationship / goal / leading / channel):
Design (holdout, staggered, or cohort) and why:
Holdout size, assignment method, and window:
Required sample size and expected time to reach it:
Data sources and owners:
Reporting cadence and audience:
```

## Task-Specific Questions

1. What is the one behavior this program is meant to change?
2. How many members enter it per month?
3. Can you randomly hold members out of the marketing journey?
4. Does finance have an agreed value per product or per PFI member?
5. Who will read the results, and how often?

## Related Skills

- **cu-marketing-context**: the shared PFI definition and goals
- **cu-lifecycle-emails**, **cu-sms**, **cu-member-retention**, **cu-member-referrals**, **cu-partner-programs**: the programs this skill measures
