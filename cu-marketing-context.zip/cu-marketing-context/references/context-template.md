# Context Document Template

Copy this structure for the marketing context document. Leave a section out if it doesn't apply. Mark internal-only items with **(internal)**.

```markdown
# Marketing Context: [Credit Union name]

**Scope:** [Whole institution / specific area, e.g. lifecycle and partnership marketing]
**Document version:** v1
**Last updated:** YYYY-MM-DD
**Owner:** [Name, team]

## Institution Overview
**One-liner:**
**Mission:**
**Charter and insurance:** [federal/state; NCUA/private]
**Size:** [approx. assets, members]
**Footprint:** [branches, regions, digital reach]
**How we create member value:**
**Current context:** [merger, rebrand, new market, etc.]

## Field of Membership
**Who can join:**
**Easiest path to join:**
**How we explain eligibility:**

## Products and Services
| Line | Key products | Priority this year? |
|---|---|---|
| Deposits | | |
| Lending | | |
| Cards | | |
| Digital | | |
| Other | | |

**Rates and fees published at:** [link]

## Member Segments
| Segment | Needs and goals | Challenge | Our value | Typical first product / join channel |
|---|---|---|---|---|
| | | | | |

## Problems and Member Needs
**Core problems members bring:**
-
**Why alternatives fall short:**
-
**Emotional tension:**

## Competitive Landscape
| Competitor type | Examples | Where they win | Where they fall short for members |
|---|---|---|---|
| National banks | | | |
| Regional/community banks | | | |
| Other credit unions | | | |
| Digital banks and fintechs | | | |

## Differentiation
| Differentiator | Why it matters to members | Proof (see Approved Claims) |
|---|---|---|
| | | |

**Why members choose and stay:**

## Objections
| Objection | Approved response |
|---|---|
| | |

**Not a good fit:**

## Switching Dynamics
**Push:**
**Pull:**
**Habit:**
**Anxiety:**
**Friction reducers:** [switch kit, direct deposit tool, branch help]

## Member Language
**How members describe the problem:**
- "[verbatim]"
**How members describe us:**
- "[verbatim]"
**Use:**
**Avoid:**

| Term | Meaning |
|---|---|
| | |

## Brand Voice
**Tone:**
**Style:**
**Personality:** [3 to 5 traits]
**Reading level:**
**On-voice example:**
**Off-voice example:**

## Approved Claims and Compliance Notes
| Claim | Substantiation | Last verified |
|---|---|---|
| | | |

**Avoid:**
-
**Required statements:**
-
**Review process:** [who reviews, typical turnaround]

## Partnerships and Community
**Partner and employer programs:**
**Community commitments and proof:**

## Goals and Measures
**Priorities:**
**Key conversion actions:**
**Metrics:** (internal)

## Changelog
*Newest first. One line per revision: what changed and why.*
- v1 (YYYY-MM-DD) — Initial context.
```
