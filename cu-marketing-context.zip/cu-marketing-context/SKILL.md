---
name: cu-marketing-context
description: Create or update a credit union's marketing context document (members, products, positioning, voice, approved claims) that other marketing skills read first. Use at the start of any project.
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (product-marketing skill, v2.1.0, MIT)
---

# Credit Union Marketing Context

You help credit union marketers create and maintain one marketing context document. It captures who the institution serves, what it offers, how it is positioned, how it sounds, and which claims are approved, so other marketing skills (and other people on the team) start from the same facts without the marketer repeating themselves.

Credit unions differ from the SaaS companies most marketing frameworks assume: members are owners, eligibility is defined by a field of membership, products are regulated, and claims need substantiation. This document reflects that.

## Step 1: Check for an existing document

Look for an existing context document before starting:
- In a Claude Project: the Project knowledge files, usually named `marketing-context.md` or similar
- Attached to the conversation
- In a coding agent: `.agents/product-marketing.md` (the location other skills in the marketingskills library read)

**If one exists:**
- Summarize what it covers, its **Document version**, and the last few **Changelog** entries
- Ask which sections to update, and gather information only for those
- On any substantive change, bump the version and add a changelog entry (Step 4)

**If none exists, offer two options:**

1. **Draft from public sources** (recommended): the marketer gives the institution's website URL and, optionally, an annual report, rates page, or brand guide. Read what is available (fetch pages if a web tool is available; otherwise ask the marketer to paste or attach them), draft every section, then ask what needs correcting.
2. **Interview**: walk through the sections conversationally, one at a time.

Most marketers prefer option 1. After the draft, ask: "What's wrong, what's missing, and what's internal-only?"

**Ask about scope early.** A large credit union is many businesses. Ask whether this document covers the whole institution or one area (for example lifecycle and partnership marketing, consumer lending, or a member segment). A focused document produces better downstream work.

## Step 2: Gather information

**Drafting from public sources:**
1. Read the homepage, about page, membership eligibility page, top product pages, rates page, and any community or impact pages
2. Draft all sections; mark anything inferred with "(draft: confirm)"
3. Leave sections that need internal knowledge (goals, metrics, objections, member language) as clear prompts rather than guesses
4. Iterate until the marketer is satisfied

**Interviewing:** for each section, briefly explain what it captures, ask two or three specific questions, confirm, and move on. Never dump every question at once.

Push for members' exact words. Phrases from member surveys, reviews, call center notes, and branch staff are worth more than polished descriptions.

**Keep confidential and personal data out.** Never record member names, account details, or individual member stories without consent. Ask before including internal metrics, unreleased products, merger details, or partner contract terms, and label anything internal-only so it is not reused in public content.

## Sections to capture

### 1. Institution overview
- One-line description and mission
- Charter type (federal or state), insurance (NCUA or private), approximate asset size and member count
- Footprint: branches, regions, digital-only reach
- Business model in plain words (member-owned, not-for-profit, returns value through rates, dividends and lower fees)
- Recent context that shapes messaging (for example a merger, rebrand, or new market)

### 2. Field of membership and eligibility
- Who can join (employer groups, associations, geography, family members)
- How eligibility is explained to prospects, including any easy path to join
- Eligibility objections and how they are answered

### 3. Products and services
- Product lines (deposits, certificates, consumer loans, auto including indirect, mortgage and home equity, cards, business, investments and insurance)
- Flagship or priority products for the current year
- Digital capabilities (app, mobile deposit, switching tools, card controls)
- Where rates and fees are published (link, not numbers; numbers go stale)

### 4. Member segments
For each priority segment (for example new members, young adults, families, homebuyers, retirees, small business owners, partner or employer groups):
- What they need and their main financial goals
- Their challenge or tension
- The value the credit union offers them
- Typical join channel and first product

### 5. Problems and member needs
- The core problems members bring (high fees, poor service, being turned down elsewhere, wanting a local relationship)
- Why big banks, fintechs, or other options fall short for them
- The emotional side (money stress, distrust of banks, fear of being judged)

### 6. Competitive landscape
- **Large national banks**
- **Regional and community banks**
- **Other credit unions** in the market
- **Digital banks and fintechs** (neobanks, high-yield savings apps, buy-now-pay-later, online lenders)
- For each, where it wins and where it falls short for members

### 7. Differentiation
- What the institution does that alternatives don't (member ownership, rates, fees, local decision-making, specific programs)
- Proof for each claim (see section 12)
- Why members choose and stay

### 8. Objections
- Top objections ("I can't join," "Switching is a hassle," "Their tech is behind," "Credit unions are small") and approved responses
- Who is not a good fit

### 9. Switching dynamics
- **Push**: what frustrates people about their current institution
- **Pull**: what draws them here
- **Habit**: what keeps them where they are (direct deposit, autopay, inertia)
- **Anxiety**: what worries them about switching (missed payments, hassle, losing a relationship)
- Tools that reduce friction (switch kits, direct deposit switching, branch help)

### 10. Member language
- How members describe their problems and the credit union, verbatim where possible
- Words to use and words to avoid (for example "members" not "customers," "dividends" on deposits)
- Glossary of institution-specific terms and product names

### 11. Brand voice
- Tone, style, and 3 to 5 personality traits
- Reading level target
- Examples of on-voice and off-voice lines

### 12. Approved claims and compliance notes
- Claims marketing may make and their substantiation (for example "ranked #X by [source, year]," "returned $X to members in [year]"), with the date each was last verified
- Claims to avoid (for example "free" where fees can apply, "best rates" without substantiation, "pre-approved" outside firm offers)
- Required statements (such as "Federally insured by NCUA," Equal Housing Opportunity for mortgage and home equity, NMLS ID where required)
- Who reviews marketing and typical turnaround
- Note: this section records what compliance has approved; it does not replace compliance review

### 13. Partnerships and community
- Employer, association, and other partner programs (SEGs), at the level appropriate to share
- Community commitments and impact themes with proof

### 14. Goals and measures
- Current marketing priorities (for example growth in members under 35, direct deposit adoption, auto loan growth, digital adoption)
- Key conversion actions
- Metrics used (members, products per member, primary financial institution share, retention), labeled internal-only where needed

Skip what doesn't apply.

## Step 3: Create the document

Use the template in [references/context-template.md](references/context-template.md). Keep it scannable: short answers, bullets, tables. Mark internal-only items with **(internal)**.

## Step 4: Confirm, version, and save

- Show the completed document and ask what needs adjusting
- **Versioning:**
  - New document: `Document version: v1` with one changelog entry, `- v1 (YYYY-MM-DD) — Initial context.`
  - Update: increment the version, update `Last updated`, and add a changelog entry at the top naming the sections changed and why. Never rewrite past entries.
  - Typo-only fixes: no version bump
- **Saving depends on where you are running:**
  - **Claude app:** produce the document as a downloadable Markdown file or document, then tell the marketer: "Add this to your Project knowledge so every chat in the Project uses it. When it changes, replace the old file."
  - **Coding agent with a file system:** save to `.agents/product-marketing.md` so skills from the original marketingskills library also find it.
- Close with: "Other marketing skills will use this context. Run this skill again anytime to update it."

## Tips

- Ask for specifics: "What's the number one reason new members say they joined?" beats "What's your value proposition?"
- Ask for an example whenever an answer is abstract.
- Summarize each section and confirm before moving on.
- Prefer links over numbers for rates and fees; they change often.
- Date every proof point; an expired award claim is a compliance problem.

## Related skills

- **cu-lifecycle-emails**: lifecycle email journeys that read this document first
- Any skill from the marketingskills library, which checks for a product marketing context document before starting
