# Partner Playbooks

One playbook per partner type: who to talk to, what to offer, what to measure, and what to watch for.

## Contents
- Employers (select employee groups)
- Associations and professional groups
- Schools, colleges, and universities
- Community and nonprofit organizations
- Auto dealers (indirect lending)
- Real estate agents and builders
- Fintech and technology partners
- Local businesses
- Partner health review

---

## Employers (select employee groups)
**Contact:** HR, benefits, or total rewards lead; for smaller employers, the owner or office manager
**Offer:** membership eligibility, financial wellness sessions, payroll direct deposit setup, a starting-out or employee loan program, small-dollar emergency loans as an alternative to payroll advances (if offered), benefits-fair presence
**Entry points:** new-hire orientation, open enrollment, intranet benefits page, payroll direct deposit form
**Measure:** accounts opened, direct deposits, session attendance, products per member
**Watch for:** approval steps to add the group to your field of membership; the employer's rules on vendor communications; keep any employee lists out of your systems unless compliance has approved the data flow

## Associations and professional groups
**Contact:** executive director, member benefits or partnerships lead
**Offer:** membership eligibility through the association, member-benefit listing, content for their newsletter, conference sponsorship, profession-specific programs (for example educators, health care workers, first responders)
**Measure:** accounts opened through the association's channels, benefit-page traffic
**Watch for:** eligibility rules that rely on association membership; payments to the association for endorsement need compliance review

## Schools, colleges, and universities
**Contact:** student affairs, financial aid, alumni relations, HR for staff
**Offer:** financial literacy programs, first-account and student checking, campus events, staff benefits as an employer partner
**Measure:** youth and young-adult accounts opened, workshop participation, conversion to first credit product later
**Watch for:** extra care marketing to minors; school rules on vendor access; co-branded card or ID programs carry specific regulations; involve compliance early

## Community and nonprofit organizations
**Contact:** executive director, development or partnerships lead
**Offer:** sponsorship, volunteer hours, financial education delivered to their clients, matched-savings or credit-builder programs
**Measure:** community impact metrics (people served, sessions delivered), brand awareness in the area, members acquired through programs
**Watch for:** keep impact claims substantiated; avoid implying the nonprofit endorses specific products unless agreed

## Auto dealers (indirect lending)
**Contact:** dealer finance manager, through your indirect lending team
**Offer:** a strong welcome for members who join through a dealer (often their first and only relationship), dealer co-op materials if your program allows
**Measure:** indirect members who open a second product within 90 days, autopay setup, early payoff and refinance-away rate
**Watch for:** dealer marketing rules in your indirect program; the member relationship starts with a loan they may not have chosen you for, so onboarding matters more (see cu-lifecycle-emails new loan journey)

## Real estate agents and builders
**Contact:** brokers, agents, builder sales offices, through your mortgage team
**Offer:** homebuyer education events, pre-qualification resources, co-hosted first-time buyer seminars
**Measure:** pre-qualifications and applications attributed to the partner, seminar attendance
**Watch for:** RESPA Section 8 prohibits giving or receiving anything of value for referrals of settlement business; co-marketing arrangements need compliance review and fair-value documentation; Equal Housing statement on all materials

## Fintech and technology partners
**Contact:** partnerships or business development lead
**Offer:** an integration or embedded experience that fills a gap (account switching, budgeting, credit building, small business tools)
**Measure:** adoption among members, products per adopting member, retention lift
**Watch for:** third-party risk management review, data sharing and privacy, who owns the member relationship and messaging, and that the experience meets your brand and accessibility standards

## Local businesses
**Contact:** owner or manager; chambers of commerce and business associations for scale
**Offer:** business accounts, member discount programs, co-hosted community events, small business workshops
**Measure:** business accounts opened, event attendance, discount program usage
**Watch for:** member discount programs implying an endorsement; keep claims and offers clear and time-bound

---

## Partner health review

Run quarterly for each active partner:

| Question | Healthy | Needs attention |
|---|---|---|
| Accounts opened this quarter vs. target | At or above | Below 50% |
| Did the partner distribute our content? | Every planned touch | Missed touches |
| Direct deposit rate of partner-sourced members | Above overall average | Below average |
| Contact still engaged? | Responsive | No reply in 60 days |
| Upcoming moments booked (orientation, enrollment, events) | Yes | None |

For partners that need attention: refresh the value exchange, find a new champion, or move them to a lighter-touch tier so staff time goes to partners that produce.
