# cu-partner-programs

Plans, pitches, runs, and measures credit union partnerships: employers (select employee groups), associations, schools, community organizations, dealers, real estate, fintechs, and local businesses.

Adapted from the `co-marketing` skill (v2.0.3) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Partner types reflect how credit unions grow, including partners that create membership eligibility
- Added a six-factor partner scoring model and a value-exchange worksheet
- Added guardrails for data sharing (partner-sends model), RESPA on real estate referrals, and indirect dealer programs
- Added eight partner playbooks and a quarterly partner health review
- Measures partner-sourced member quality, not just volume

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson. Not legal advice; route all marketing through your institution's compliance review.
