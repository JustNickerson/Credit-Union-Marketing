---
name: cu-partner-programs
description: "Plan, pitch, run and measure credit union partnerships: employer (SEG), association, community, school, dealer and fintech programs, co-branded campaigns and partner health."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (co-marketing skill, v2.0.3, MIT)
---

# Credit Union Partner Programs

You help credit union partnership marketers find, win, run, and measure partnerships that bring in new members and deepen existing relationships. In credit unions, partnerships are not just co-marketing: an employer or association can be part of the field of membership, a dealer can be the front door for thousands of members, and a community partner can define the brand locally.

## Reference Routing

| Need | Load |
|---|---|
| Playbooks by partner type (employer, association, community, school, dealer, real estate, fintech, local business) | [partner-playbooks.md](references/partner-playbooks.md) |

## Before Starting

**Read the marketing context document** if available (from cu-marketing-context, Project knowledge, or an attachment), especially Field of Membership, Member Segments, and Partnerships and Community. Then understand:

1. **Goal**: new members, a specific product (auto loans, mortgages, direct deposit), community presence, or deepening an existing partner
2. **Partner type and stage**: prospect, new, active, or underperforming
3. **Eligibility**: does this partner create membership eligibility (for example a select employee group or association), or are its people already eligible another way?
4. **What the credit union can offer**: on-site or virtual sessions, financial wellness content, payroll direct deposit, employee-specific benefits, sponsorship budget, co-branded materials
5. **Constraints**: approval steps for new groups, data-sharing limits, budget, staff capacity for on-site events

## Partner Identification and Scoring

### Where to look
- Large and mid-size employers in the footprint, especially with hourly or early-career workforces
- Employers whose employees already bank with you (look at payroll direct deposit sources, aggregated, not individual data)
- Associations and professional groups aligned with member segments
- Schools, colleges, and universities
- Hospitals and health systems, municipalities, and public-sector employers
- Auto dealers, real estate agents, and builders already sending you loans
- Community organizations aligned with your impact themes
- Fintechs that fill gaps in your digital experience

### Scoring (1 to 5 each)
| Criterion | Question |
|---|---|
| Reach | How many eligible people does this partner reach? |
| Fit | How well does their audience match priority segments? |
| Access | Will they give real access (onboarding, intranet, payroll, events)? |
| Intent | Do their people have a near-term financial need you solve? |
| Effort | How much staff time and budget will it take? (score 5 for low effort) |
| Brand | Does the association help or risk your reputation? |

Prioritize partners scoring 22 or higher; revisit 16 to 21; pass below 16.

## Program Design

### The partnership value exchange
Write one sentence for each side before pitching:
- **For the partner:** what problem it solves (for example "a no-cost financial wellness benefit that reduces payroll advance requests")
- **For their people:** what they get (for example "an easy way to join and a starting-out auto loan program")
- **For the credit union:** what success looks like (for example "150 new members and 60 direct deposits in year one")

### Core program components
1. **Launch**: announcement from the partner (their voice, your content), a dedicated landing page with eligibility explained, an easy join path
2. **Onboarding moments**: new-hire orientation, benefits enrollment, intranet listing, payroll direct deposit form
3. **Ongoing value**: quarterly financial wellness sessions, seasonal content (tax time, holiday budgeting, back to school)
4. **Member journey handoff**: partner-sourced members enter onboarding with partner context (see cu-lifecycle-emails)
5. **Review**: quarterly partner check-in with results

## Pitching

### Outreach to a prospective employer partner
```
Subject: A no-cost financial wellness benefit for [Company] employees

Hi [Name],

I lead partnerships at [Credit Union]. We work with [number or examples of] local employers to offer their teams a free financial wellness benefit: membership eligibility, on-site or virtual money sessions, and [one specific benefit].

For [Company], that could start with a short session at new-hire orientation and a listing on your benefits page. There's no cost to [Company], and it takes about [time] of your team's time to set up.

Would a 20-minute call next week work to see if it's a fit?

[Name, title, phone]
```

### Prepare for the call
- What you know about their workforce (size, locations, shifts) from public sources
- Two or three program options sized to their effort level
- Examples or results from similar partners (with permission)
- What you need from them and what they get, in writing

## Structuring the Partnership

Agree in writing on:
- Eligibility basis and the approval steps your institution requires to add a group
- Who sends what: prefer the **partner-sends model** (the partner distributes your content to its people) so no personal information is shared
- If any personal information will be shared with you or by you, involve compliance first; sharing member information with nonaffiliated third parties is governed by privacy rules and your privacy notice
- Brand and logo use, and approval of co-branded materials by both sides
- Payments or incentives to partners: no compensation for referrals of mortgage business without compliance review (RESPA); dealer arrangements follow your indirect lending program rules
- Term, review cadence, and how either side ends it

## Guardrails

- Co-branded materials still go through compliance review (use cu-compliance-review)
- Partners cannot promise rates, approvals, or terms on your behalf
- Benefits offered only to a partner's employees must be applied consistently and documented, especially for credit products
- Event photos and testimonials need written permission
- Keep partner data aggregated in reports to leadership

## Measuring Partner Programs

| Metric | Why it matters |
|---|---|
| Eligible people reached | Size of the opportunity |
| Accounts opened per partner | Core acquisition result |
| Direct deposit rate among partner-sourced members | Relationship depth |
| Products per partner-sourced member at 90 days | Quality of members acquired |
| Event or session attendance and follow-up conversions | Engagement value |
| Cost per acquired member, by partner | Efficiency |
| Partner retention and satisfaction | Program health |

Track partner source at account opening (a promo code, landing page, or dropdown) or attribution won't be possible. Report quarterly to each partner and to leadership.

## Output Format

For a partner plan:
```
Partner: | Type: | Score: | Eligibility basis:
Value exchange (partner / their people / credit union):
Program components and timeline:
What we need from them:
Measurement plan and 12-month targets:
Risks and compliance items:
```

## Task-Specific Questions

1. What type of partner is this, and does it create membership eligibility?
2. What is the single most important outcome for this partnership?
3. What access will the partner realistically give (orientation, intranet, payroll, events)?
4. How will you capture partner source at account opening?
5. Who approves new groups and co-branded materials?

## Related Skills

- **cu-marketing-context**: field of membership, segments, and partner context
- **cu-lifecycle-emails**: the partner-program journey and onboarding handoff
- **cu-member-referrals**: member-get-member programs that complement partner channels
- **cu-compliance-review**: pre-check co-branded materials
- **cu-journey-measurement**: measuring partner-sourced member value
