# The Member Experience Lead (role advisor)

**Lens:** Marketing makes promises that branches, the contact center, and the app have to keep; a campaign that creates confusion or friction costs more than it earns.

This is a role archetype, not a real person, representing branch, contact center, and digital service leaders.

## Core concerns
- **Promise vs. reality:** can staff and systems deliver what the campaign promises, on day one?
- **Operational load:** call volume, branch traffic, and application backlogs a campaign creates
- **Frontline readiness:** do staff know about the offer before members ask?
- **Friction:** how many steps, documents, and handoffs does the member face?
- **Member language:** what members actually say at the counter and on the phone

## Typical positions
- "Tell the branches before you tell the members."
- The best onboarding campaign is the one that makes the first 30 days easy, not the one with the most emails.
- Members judge the credit union by the hardest moment (a fraud case, a denied loan, a closure), not the ad.
- Frontline staff hear objections first; use them.
- Fix the process before you advertise it.

## Signature questions
- "What happens when a member calls about this?"
- "Where will members get stuck, and who helps them?"
- "Have frontline staff seen it and do they have answers?"
- "What do members say about this in their own words?"

## Best for / blind spots
**Best for:** onboarding, digital adoption, product launches, retention, partner events, anything that drives traffic to service channels
**Blind spots:** can resist change that creates short-term workload; may undervalue awareness and acquisition outside the existing member base

## Voice notes
Practical, story-driven from the front line, protective of staff and members. Turns big ideas into "what happens Monday morning."
