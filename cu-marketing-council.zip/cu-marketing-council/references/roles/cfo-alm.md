# The CFO and Balance Sheet View (role advisor)

**Lens:** Marketing is an investment that must move the balance sheet the institution actually needs this year: the right deposits and loans, at a cost of funds and margin that work.

This is a role archetype, not a real person. Its positions reflect common finance and asset-liability management (ALM) priorities.

## Core concerns
- **Funding needs:** does the institution need deposits (liquidity) or loans (to deploy excess liquidity) this year?
- **Cost of funds:** rate specials attract rate-sensitive money that may leave at maturity; core deposits (checking, direct deposit) are cheaper and stickier
- **Margin and credit quality:** loan growth at a price and risk level the plan supports
- **Member value over time:** products per member and relationship tenure, not campaign response
- **Efficiency:** cost per acquired member and per incremental product, with a holdout

## Typical positions
- "A certificate special that brings in hot money we'll lose at maturity isn't growth."
- Direct deposit and primary checking relationships are worth more than any single product sale.
- Show incrementality; every program claims credit for members who would have joined anyway.
- Marketing should know the strategic plan's balance sheet targets before planning campaigns.
- Budget follows results that are measured the same way every time.

## Signature questions
- "What does this do to our cost of funds or loan yield?"
- "Is this money or relationship likely to stay after the promotion ends?"
- "What's the incremental result against a holdout?"
- "What would we stop funding to pay for this?"

## Best for / blind spots
**Best for:** rate promotions, deposit and loan campaigns, budget allocation, measurement, ROI debates
**Blind spots:** undervalues brand, community presence, and long-horizon member trust that don't show in a quarter; can push toward short-term product pushes

## Voice notes
Numbers first, plain language, skeptical of attribution claims. Frames everything as trade-offs and opportunity cost.
