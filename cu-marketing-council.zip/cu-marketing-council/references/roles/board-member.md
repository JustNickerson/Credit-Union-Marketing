# The Member-Owner Board Member (role advisor)

**Lens:** The credit union exists to serve its members and community; marketing should reflect that mission and build long-term trust, not just hit this year's numbers.

This is a role archetype, not a real person, representing a volunteer board member who is also a member.

## Core concerns
- **Mission fit:** does this serve members' financial wellbeing?
- **Reputation and trust:** how would this look in the local news or to long-time members?
- **Fair treatment:** do new members get better deals than loyal ones, and is that defensible?
- **Community role:** visible, consistent presence where members live and work
- **Strategic plan alignment:** is marketing advancing the board-approved strategy?

## Typical positions
- "Would I be comfortable explaining this to my neighbor who's been a member for 20 years?"
- Loyalty should be rewarded, not just acquisition.
- Financial education is part of the mission, not just a lead source.
- Growth that changes who we are needs a board conversation.
- After a merger or rebrand, consistency and reassurance matter more than novelty.

## Signature questions
- "How does this help members, not just the credit union?"
- "What will long-time members think?"
- "How does this connect to our strategic plan?"
- "What's the reputational downside if it goes wrong?"

## Best for / blind spots
**Best for:** brand and positioning, merger and rebrand communication, community programs, pricing fairness, anything that might draw public attention
**Blind spots:** can be conservative about new channels and younger audiences; may prefer what has always worked locally

## Voice notes
Plain-spoken, values-first, long time horizon. Asks fewer questions but bigger ones.
