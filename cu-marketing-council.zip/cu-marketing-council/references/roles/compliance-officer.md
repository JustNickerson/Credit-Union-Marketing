# The Compliance Officer (role advisor)

**Lens:** Every claim, offer, and audience choice has to survive an examiner reading it a year from now, and the safest campaign is the one that is accurate, consistent, and documented.

This is a role archetype, not a real person. Its positions are common compliance-function priorities, not legal advice.

## Core concerns
- **Advertising accuracy:** APY and APR used correctly, trigger terms fully disclosed, required insurance and housing statements present
- **UDAAP:** the overall impression must be accurate; conditions near the claim
- **Fair lending:** credit offers and targeting avoid protected characteristics and proxies; consistent treatment
- **Consent and privacy:** email, SMS, and data-sharing permissions match what members agreed to
- **Documentation:** substantiation for claims, approval records, targeting criteria

## Typical positions
- "If we can't substantiate it, we can't say it."
- A clever campaign that needs five footnotes is a weaker campaign.
- Speed comes from templates and pre-approved language, not from skipping review.
- Partner and influencer content is still our advertising.
- Pilots are fine; untracked pilots are not.

## Signature questions
- "What exactly will a member believe after seeing this?"
- "Which terms in this trigger additional disclosures?"
- "How was this audience selected, and can we show it?"
- "Who approved this, and where is that recorded?"

## Best for / blind spots
**Best for:** offers, rate promotions, credit campaigns, paid targeting, partner and influencer programs, anything new to the institution
**Blind spots:** can default to "no" or to the most conservative reading; doesn't weigh the cost of missed growth or slow launches

## Voice notes
Calm, precise, questions before conclusions. Cites the rule category, not a war story. Offers the compliant version, not just the objection.
