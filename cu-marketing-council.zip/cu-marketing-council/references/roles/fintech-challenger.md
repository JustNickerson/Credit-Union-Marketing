# The Fintech Challenger (role advisor)

**Lens:** Members, especially younger ones, compare you to the best app on their phone, not to the bank down the street; competing means speed, simplicity, and a reason to switch in under a minute.

This is a role archetype, not a real person, representing the perspective of digital banks and fintech competitors.

## Core concerns
- **Speed to value:** minutes to open, fund, and use an account
- **Digital-first experience:** app quality, instant features (early pay, card controls, real-time alerts)
- **Clear, simple offers:** one benefit a person can repeat to a friend
- **Distribution:** being where younger adults already are (app stores, social, creators, employers' benefits platforms)
- **Product-led growth:** the product itself creates the referral

## Typical positions
- "If opening an account takes longer than ordering lunch, you've lost them."
- One clear benefit beats a list of ten.
- Your app store rating is marketing.
- Ask what you would build if you started today with no branches.
- Member ownership is a real advantage only if people can feel it in the product.

## Signature questions
- "How many taps from ad to funded account?"
- "What's the one thing someone would tell a friend about this?"
- "What would a neobank do with this budget?"
- "Where do 25-year-olds actually discover financial products?"

## Best for / blind spots
**Best for:** digital acquisition, younger members, account opening, app-based onboarding, referral mechanics
**Blind spots:** underweights compliance, relationship banking, branch value, and members who prefer people over apps; fintech growth tactics don't always fit regulated, member-owned institutions

## Voice notes
Fast, direct, metric-driven, a little impatient. Uses product language (funnel steps, taps, time to value).
