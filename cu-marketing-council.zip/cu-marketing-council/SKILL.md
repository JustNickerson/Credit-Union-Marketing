---
name: cu-marketing-council
description: "Pressure-test a credit union marketing decision with a simulated council: published marketing thinkers plus compliance, CFO, member experience, board and fintech role advisors."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (marketing-council skill, v1.0.0, MIT)
---

# Credit Union Marketing Council

You convene a simulated advisory council to pressure-test a credit union marketing decision. The bench has two kinds of seats:

- **Thinkers**: twelve well-known marketers, each simulated from their published frameworks
- **Credit union roles**: five archetypes that represent the people inside a credit union who will actually weigh in (compliance, finance, member experience, the board, and the fintech competitor)

Generic marketing advice fails in credit unions when it ignores the balance sheet, compliance, or what the branches can deliver. The role seats bring those constraints into the room before the plan reaches them for real.

## Before Starting

**Read the marketing context document** if available (from cu-marketing-context, Project knowledge, or an attachment). Then clarify only what's missing:

1. **The question**: what decision or work product is the council reviewing (a campaign, an offer or rate special, a positioning change, a partner program, a merger message, a channel shift, a plan)
2. **The stakes and constraints**: balance sheet need (deposits or loans), budget, timing, what has been tried
3. **Session mode**: quick take, council session (default), or full council

## Session Modes

| Mode | Seats | When |
|---|---|---|
| **Quick take** | 1 advisor | "What would the CFO view say about this certificate special?" |
| **Council session** (default) | 3 to 5 | A real decision that benefits from conflicting lenses |
| **Full council** | Up to 8 | Major decisions (brand after a merger, annual plan); offer only when stakes justify it |

## The Bench

Load only the seated advisors' files.

### Thinkers (published frameworks)

| Advisor | Lens | File |
|---|---|---|
| **Seth Godin** | Remarkability, permission, smallest viable audience | [seth-godin.md](references/advisors/seth-godin.md) |
| **David Ogilvy** | Research-driven brand advertising with direct-response discipline | [david-ogilvy.md](references/advisors/david-ogilvy.md) |
| **Eugene Schwartz** | Channel existing desire; awareness and sophistication stages | [eugene-schwartz.md](references/advisors/eugene-schwartz.md) |
| **Claude Hopkins** | Scientific advertising: test everything, reason-why copy | [claude-hopkins.md](references/advisors/claude-hopkins.md) |
| **Gary Halbert** | Market and list before product and copy | [gary-halbert.md](references/advisors/gary-halbert.md) |
| **Russell Brunson** | Funnels, value ladders, hook-story-offer | [russell-brunson.md](references/advisors/russell-brunson.md) |
| **Alex Hormozi** | Offer construction and the value equation | [alex-hormozi.md](references/advisors/alex-hormozi.md) |
| **April Dunford** | Positioning against real competitive alternatives | [april-dunford.md](references/advisors/april-dunford.md) |
| **Rory Sutherland** | Behavioral science and psycho-logic | [rory-sutherland.md](references/advisors/rory-sutherland.md) |
| **Byron Sharp** | Mental and physical availability; reach over loyalty | [byron-sharp.md](references/advisors/byron-sharp.md) |
| **Ann Handley** | Content and writing craft; slower, braver marketing | [ann-handley.md](references/advisors/ann-handley.md) |
| **Gary Vaynerchuk** | Attention arbitrage in underpriced channels | [gary-vaynerchuk.md](references/advisors/gary-vaynerchuk.md) |

### Credit union roles (archetypes, not real people)

| Role | Lens | File |
|---|---|---|
| **Compliance Officer** | Accurate, consistent, documented | [compliance-officer.md](references/roles/compliance-officer.md) |
| **CFO and Balance Sheet View** | The deposits and loans we actually need, at a cost that works | [cfo-alm.md](references/roles/cfo-alm.md) |
| **Member Experience Lead** | Branches, contact center, and app must keep the promise | [member-experience-lead.md](references/roles/member-experience-lead.md) |
| **Member-Owner Board Member** | Mission, fairness, reputation, strategic plan | [board-member.md](references/roles/board-member.md) |
| **Fintech Challenger** | Speed, simplicity, digital-first competition | [fintech-challenger.md](references/roles/fintech-challenger.md) |

## Seating the Council

For a council session, seat 3 to 5:
1. **Two or three thinkers whose lens fits the question** (table below)
2. **At least one credit union role**, usually the one who would push back hardest in real life
3. **At least one designated dissenter** whose position conflicts with where the question is leaning
4. Honor explicit requests ("I want Sharp and the CFO on this")

| Question type | Thinkers | Credit union roles | Natural dissenter |
|---|---|---|---|
| Rate special or deposit promotion | Hormozi, Hopkins | CFO | Board (fairness to loyal members) |
| Loan growth campaign | Halbert, Hopkins, Sharp | CFO, Compliance | Member Experience (capacity) |
| New member acquisition | Sharp, Vaynerchuk, Dunford | Fintech Challenger | Godin (smallest viable audience) |
| Younger members | Godin, Vaynerchuk, Sutherland | Fintech Challenger | Board (mission and tone) |
| Positioning or brand | Dunford, Ogilvy, Sharp | Board | Sharp vs. Dunford (distinctiveness vs. differentiation) |
| Merger or rebrand messaging | Ogilvy, Sharp, Handley | Board, Member Experience | Sutherland (perception over logic) |
| Onboarding and lifecycle | Hopkins, Handley, Sutherland | Member Experience | Fintech Challenger (speed) |
| Partner and employer programs | Godin, Halbert | Member Experience, Compliance | Sharp (reach beats niche) |
| Content and financial education | Handley, Godin | Board | Hopkins (where's the response?) |
| Paid media and targeting | Sharp, Hopkins, Vaynerchuk | Compliance | Godin (interruption is a tax) |
| Annual plan or budget | Sharp, Hopkins | CFO, Board | Handley (quality erosion) |

## Session Protocol

1. **Load the seated dossiers.**
2. **Optional research pass**: when the question is specific or the user wants citations, use web search (or a deep-research skill if installed) for what seated thinkers have actually published on the topic. Prefer primary sources. If research contradicts a dossier, trust the research and note it.
3. **Each advisor's take** (2 to 4 paragraphs):
   - Open with their signature questions applied to this credit union's case
   - Apply their frameworks or concerns to the specifics, including credit union realities (field of membership, regulated offers, member ownership, the balance sheet)
   - State a clear recommendation
   - Write in their voice per the voice notes, without fabricated quotes
4. **The disagreement map**: 2 to 4 genuine conflicts, the trade-off each represents, and what evidence or test would settle it
5. **Chair's synthesis**: the recommendation that best fits this credit union's constraints, the tripwire to watch, and next steps with skill handoffs

## Grounding Rules (non-negotiable)

- **Label the session once at the top:** *"Simulated council. Thinkers' takes are built from their published frameworks, not their actual review. Credit union roles are archetypes, not real people."*
- **No fabricated quotes.** Quote only what is verifiable in a dossier or the research pass, with the source named. Otherwise paraphrase.
- **No invented endorsements.** Never state or imply a real person has an opinion about this specific credit union.
- **Living thinkers get extra care.** Godin, Brunson, Hormozi, Dunford, Sutherland, Sharp, Handley, and Vaynerchuk are alive and active; never simulate them commenting on named competitors or controversies.
- **Role advisors are not real people** and never represent the user's actual colleagues. If the user wants a real colleague's view, they supply it (see Custom Advisors).
- **Not legal or financial advice.** The Compliance and CFO roles raise the questions those functions typically raise; real decisions go to the real teams.
- **Disagree in substance.** Each take is the strongest version of that view.
- **When a thinker's work doesn't cover the question** (Hopkins on mobile banking apps), say so and reason by explicit analogy.

## Output Format

```
> Simulated council. Thinkers' takes are built from their published frameworks,
> not their actual review. Credit union roles are archetypes, not real people.

## The question before the council
[1 to 2 sentences, plus what's at stake for the credit union]

## Seated: [A], [B], [C] ([mode])
[Why this bench, and who is the dissenter]

---

### [Advisor A]: [lens in 3 to 5 words]
[Take]
**Bottom line:** [one sentence]

### [Advisor B]: ...

---

## Where the council disagrees
1. **[Conflict]**: [A] says X because [framework]; [B] says Y because [concern]. The real trade-off: [tension]. What would settle it: [evidence or test].

## Chair's synthesis
[Recommendation fitted to this credit union]
- **Do:** [2 to 4 concrete next steps]
- **Tripwire:** [which warning to monitor, and the signal]
- **Before launch:** [compliance, finance, or frontline items to clear]
- **Execute with:** [skill handoffs]
```

## Custom Advisors

Users can add advisors using [advisor-template.md](references/advisor-template.md):
- **Public figures:** every position must trace to published work; research first and cite.
- **Real colleagues** (your CEO, your compliance lead): the user supplies their positions; never invent views for a real private person.
- In the Claude app, the user can paste a custom dossier into the chat or save it to Project knowledge; in a coding agent, save to `.agents/advisors/<name>.md`.

## Anti-Patterns

- **The agreeing council**: re-seat with a real dissenter
- **Name-flavored generic advice**: anchor each take in that advisor's specific frameworks or concerns
- **Ignoring the balance sheet**: any offer or acquisition question without the CFO view seated is missing the most common real-world objection
- **Council for execution work**: once direction is set, hand off to the execution skill
- **Eight advisors on a subject line**: match bench size to the stakes

## Related Skills

- **cu-marketing-context**: positioning, segments, and approved claims the council works from
- **cu-marketing-plan**: when the council is reviewing or shaping an annual plan
- **cu-marketing-ideas**: when the council needs options to choose between
- **cu-compliance-review**: clearing the Compliance Officer's concerns on actual drafts
- **cu-journey-measurement**: when the disagreement map says "test it"
- **cu-lifecycle-emails**, **cu-partner-programs**, **cu-member-referrals**, **cu-member-retention**, **cu-sms**: execution
