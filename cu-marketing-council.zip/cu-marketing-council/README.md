# cu-marketing-council

Pressure-tests a credit union marketing decision with a simulated council: twelve well-known marketing thinkers (simulated from their published frameworks) plus five credit union role advisors that represent the people who will actually weigh in.

Adapted from the `marketing-council` skill (v1.0.0) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. The twelve thinker dossiers are carried over unchanged. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Added five credit union role advisors, written as archetypes rather than real people: **Compliance Officer**, **CFO and Balance Sheet View**, **Member Experience Lead**, **Member-Owner Board Member**, and **Fintech Challenger**
- Every council session seats at least one credit union role, so balance sheet, compliance, and frontline realities show up before the real meetings do
- New seating map for credit union questions: rate specials, loan growth, younger members, merger messaging, partner programs, annual plans
- Chair's synthesis adds a "before launch" line for compliance, finance, and frontline items
- Grounding rules extended so role advisors are never presented as real colleagues

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson.
