---
name: cu-sms
description: "Plan and write credit union text messaging: consent and opt-out, keeping marketing separate from fraud and account alerts, anti-smishing design, lifecycle texts and measurement."
metadata:
  version: 1.0.0
  adapted-from: coreyhaines31/marketingskills (sms skill, v1.1.0, MIT)
---

# Credit Union Text Messaging

You help credit unions use text messaging for lifecycle marketing without breaking consent rules or teaching members to trust messages that scammers can copy. For a financial institution, texting has two jobs at once: be useful, and be recognizably safe. Members receive fake "credit union" texts every week.

This skill is a drafting aid, not legal advice. Consent and opt-out rules for texting have changed several times recently; confirm the current requirements with compliance before launch.

## Before Starting

**Read the marketing context document** if available. Then understand:

1. **Message types in use**: fraud and security alerts, one-time passcodes, account alerts, servicing (payment reminders), marketing
2. **Platform and numbers**: which SMS provider, short code or registered 10-digit long code (10DLC), and how campaigns are registered
3. **Consent capture**: where and how members opt in today, and what disclosure language they see
4. **Opt-out handling**: how STOP is processed, and whether opting out of marketing affects other message types in your setup
5. **Approvals**: compliance, fraud or security team, digital banking team

## Three Message Buckets

Keep these separate in consent, sending numbers or registered campaigns, and reporting.

| Bucket | Examples | Consent basis (confirm with compliance) |
|---|---|---|
| **Security** | Fraud alerts, suspicious transaction confirmations, one-time passcodes | Consent given for alerts; certain free-to-member fraud and breach alerts have specific FCC conditions |
| **Account and servicing** | Payment due reminders, low-balance alerts, deposit received, maturity reminders | Prior express consent, typically captured when the member provides a mobile number for account communications |
| **Marketing** | Product offers, promotions, event invitations, cross-sell | **Prior express written consent** with clear disclosures |

Rules:
- Never put marketing content inside a security or servicing text
- Marketing consent is not a condition of membership or of getting a product
- Decide with compliance how opt-outs are scoped across buckets, and make sure members can always keep fraud alerts

## Consent and Opt-In

Marketing opt-in disclosure should include:
- Program name and the credit union's name
- What messages they'll receive and how often ("up to 4 messages per month")
- "Message and data rates may apply"
- How to opt out ("Reply STOP to cancel") and get help ("Reply HELP for help")
- That consent isn't required to become a member or obtain a product
- Links to the SMS terms and privacy policy

Opt-in sources: digital banking settings, account opening (a separate, unchecked marketing box), keyword text-in ("Text JOIN to 12345"), web forms, branch tablets. Store each consent with timestamp, source, phone number, and the exact disclosure shown.

**Confirmation message:**
```
[Credit Union]: You're signed up for member offers and tips, up to 4 msgs/mo. Msg & data rates may apply. Reply HELP for help, STOP to cancel.
```

## Opt-Out and HELP

- Honor STOP and common variants (STOP, END, CANCEL, UNSUBSCRIBE, QUIT, REVOKE, OPT OUT) automatically
- Treat plain-language requests ("please stop texting me") and opt-outs through other channels as opt-outs too
- Honor opt-outs promptly, within the time current FCC rules require; one confirmation message is allowed
- HELP replies include the credit union name, support phone number, and STOP instructions

**Opt-out confirmation:**
```
[Credit Union]: You've been unsubscribed from member offers. You'll still get fraud alerts you've signed up for. Questions? Call [phone].
```
(Adjust the second sentence to match how your institution scopes opt-outs.)

## Anti-Smishing Design

Make real texts easy to tell apart from scams, and say the same thing every time:
- Start every message with the credit union's name
- Send from consistent, published numbers, and list them on your website
- Links only to your own domain or a registered branded short domain; never generic link shorteners
- **Never** ask for passwords, PINs, full account or card numbers, or one-time codes, and never ask members to call a number other than your published one
- Avoid urgency language scammers use ("account locked," "verify now," "final notice")
- Include the safety line periodically: "[CU] will never text you asking for your PIN, password, or code."
- Prefer "Open the [CU] app to view" over links for anything account-related

## Quiet Hours and Frequency

- No marketing texts before 8 a.m. or after 9 p.m. in the member's local time; some states are stricter, so many institutions use 9 a.m. to 8 p.m. as a safe default
- Cap marketing at a stated frequency (and keep below it)
- Don't send marketing during an active fraud case, collections, or complaint
- Security alerts can be sent at any time

## Lifecycle Text Templates

Keep messages under 160 characters where possible, one link at most, the CU name first.

**New member welcome (marketing or account, depending on consent):**
```
[CU]: Welcome to [CU], [First name]! Get the app to deposit checks and set alerts: [link]. We'll never text asking for your PIN or code.
```

**Digital banking nudge:**
```
[CU]: Set up mobile banking in about 2 minutes: [link]. Need help? Call [phone].
```

**Direct deposit (marketing):**
```
[CU]: Get paid to your [CU] account. Grab your pre-filled direct deposit form in the app under Account > Direct Deposit.
```

**Loan payment reminder (servicing):**
```
[CU]: Your auto loan payment is due [date]. Pay in the app or set up autopay. Reply STOP to opt out of reminders.
```

**Certificate maturity (servicing reminder; required notices still apply):**
```
[CU]: Your certificate matures [date]. Review your options in the app before [grace period end].
```

**Event or workshop (marketing):**
```
[CU]: Free first-time homebuyer workshop [date] at [location]. Save your seat: [link]. Reply STOP to opt out.
```

**Promotion (marketing; rate needs disclosures on the landing page and as compliance requires in the text):**
```
[CU]: New 12-month certificate special. See rate and terms: [link]. Reply STOP to opt out.
```

Run every marketing text through cu-compliance-review before sending.

## Registration

- Register the brand and each campaign use case (marketing, account notifications, security) with your SMS provider for 10DLC, or use a short code
- Sample messages in the registration should match what you actually send
- Unregistered or mismatched traffic gets filtered by carriers

## Measurement

| Metric | Notes |
|---|---|
| Opt-in rate by source | Which entry points work |
| Delivery rate | Low rates signal registration or carrier filtering issues |
| Click-through rate | Use unique tracked links on your own domain |
| Goal conversion | The behavior (app enrollment, direct deposit), vs. a holdout |
| Opt-out rate per send | Watch for spikes after promotional sends |
| Member reports of suspicious texts | A rising count may mean scammers are imitating you; coordinate with fraud |

## Output Format

```
Program: | Bucket: security / servicing / marketing
Consent basis and opt-in source:
Messages (copy, trigger, timing, frequency cap):
Opt-out scope:
Anti-smishing checks:
Quiet hours and suppression:
Measurement plan:
```

## Task-Specific Questions

1. Which message types do you send today, and from which numbers?
2. Where do members opt in to marketing texts, and what do they see?
3. How does your platform scope a STOP across message types?
4. Has your fraud team seen scam texts imitating you recently?

## Related Skills

- **cu-lifecycle-emails**: the journeys these texts support
- **cu-compliance-review**: pre-check every marketing text
- **cu-marketing-context**: voice and approved claims
- **cu-journey-measurement**: measuring SMS lift with holdouts
