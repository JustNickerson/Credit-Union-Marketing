# cu-sms

Plans and writes credit union text messaging that is useful and recognizably safe: consent and opt-out, separate message buckets, anti-smishing design, lifecycle templates, and measurement.

Adapted from the `sms` skill (v1.1.0) in Corey Haines' [marketingskills](https://github.com/coreyhaines31/marketingskills) library. MIT licensed; see [LICENSE](LICENSE).

## What changed from the original

- Separates security, servicing, and marketing texts, each with its own consent basis
- Added anti-smishing design rules so real texts are easy to tell from scams
- Rewrote templates for member journeys (welcome, digital banking, direct deposit, payment and maturity reminders)
- Removed e-commerce flows (abandoned cart, browse abandonment) and WhatsApp

Part of [credit-union-marketing-skills](../../README.md). Adapted by Mark Nickerson. Not legal advice; route all marketing through your institution's compliance review.
